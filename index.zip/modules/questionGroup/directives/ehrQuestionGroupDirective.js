"use strict";

function ehrQuestionGroupDirective() {
    return {
        templateUrl: "modules/questionGroup/templates/questionGroup.html",
        scope: {
            'ques': "<",
            'prefix': "<",
            'group':"<",
            'questionIndex':"<"
        },
        controller: "questionGroupController",
        controllerAs: "ctrl",
        link: function (scope, element, attrs, ngModel) {

        }
    };
}

export { ehrQuestionGroupDirective };