"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";
const mbt4Controller = function mbt4Controller($scope, clientService, utilityService) {
    const selectedValues = [];

    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $scope.currentSelectedValue = null;
        if (!$scope.ques && $scope.ques.childAnswerGroup) return;
        $scope.subQuestionGroup = clientService.getQuestionGroupByName($scope.ques.childAnswerGroup);
        $scope.subQuestionGroup.questions = this.extractGroupQuestions($scope.subQuestionGroup, true);
        $scope.answerGroups = clientService.getAnswerGroupsFor($scope.subQuestionGroup.uniqueId) || [];

        $scope.ques.Answer = {};
        const options = this.GetArray($scope.ques.comboOptions);
        options.forEach(option => {
            const answerGroups = $scope.answerGroups.filter(a => a.data.includes(`${option}`));
            if (!answerGroups || !answerGroups.length) return;
            $scope.ques.Answer[option] =
                answerGroups.reduce((result, answerGroup) => {
                    const group = angular.copy($scope.subQuestionGroup);
                    group.questions.forEach(question => this.setQuestionProperties(question, option));
                    answerGroup.answers.forEach(ans => {
                        const qId = this.extractQuestionId(ans);
                        const question = group.questions.find(q => q.data.includes(`"uniqueID":${qId}`));
                        if (!question) return;
                        question.Answer = clientService.extractAnswer(question, ans);
                    });
                    result.push(group);
                    return result;
                }, []);
        });
        const derigester = $scope.$watch(()=>$scope.ques.Answer, (newVal, oldVal)=>{
            if(newVal === oldVal) return;
            // //derigester();
            $scope.ques.isAnswerEdited = true;
        }, true);
    };

    this.setSelectedValue = function setSelectedValue(value) {
        if ($scope.selectedValue === value) {
            $scope.selectedValue = null;
            return;
        }
        $scope.selectedValue = value;
        if ($scope.ques.Answer[value]) {
            $scope.groups = $scope.ques.Answer[value];
            return;
        }
       
        const groups = [];
        $scope.selectedValue = value;
        this.addNewRow(value);
    }

    this.updateAnswer = function updateAnswer() {
        if( $scope.selectedValue === null ||  $scope.selectedValue === undefined) return;
        const selectedValue = $scope.selectedValue;
        $scope.ques.Answer[selectedValue] = $scope.ques.Answer[selectedValue] || {};

        $scope.groups.reduce((result, group) => {
            const questions = group.questions.reduce((subResult, ques) => {
                if (ques.Answer) subResult[ques.uniqueId] = ques.Answer;
                return subResult;
            }, {});
            result.push(questions);
            return result;
        }, []);
    }

    this.addNewRow = function addNewRow(value, pushToAllGroups) {
        const group = angular.copy($scope.subQuestionGroup);
        group.questions.forEach(question => {
            this.setQuestionProperties(question, value);

        });
        // if (!pushToAllGroups) return group;
        $scope.ques.Answer[value] = $scope.ques.Answer[value] || [];
        $scope.ques.Answer[value].push(group);
        //$scope.groups.push(group);
        $scope.groups = $scope.ques.Answer[value];
    };

    this.removeRow = function removeRow(index) {
        $scope.groups.splice(index, 1);
    };

    this.onBlur = function onBlur() {
        console.log("blur");
        this.updateAnswer();
        $scope.selectedValue = null;
    };

    this.setQuestionProperties = function setQuestionProperties(question, selectedOption) {
        question.label = selectedOption;
        question.Id = `${selectedOption}_${question.Id}`;
        question.width = question.isLabel ? 2 : 3;
        question.hideIcon = "calendar";
        question.type = utilityService.getQuestionType(question);
    }

    this.getAnswerCount = function getAnswerCount(option) {
        const answers = $scope.ques.Answer[option];
        return answers && answers.length > 0 ? `(${answers.length}) ` : "";
    }
    this.init();
};

export { mbt4Controller };