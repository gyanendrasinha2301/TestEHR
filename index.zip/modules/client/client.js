"use strict";

import 'angular-resource';

import "../common/common";
import { clientService } from "./services/clientService";
import { saveService } from "./services/saveService";

const clientModule = angular.module("ehr.client", ["ngResource", "ehr.common"]);
clientModule.service("saveService", ["$resource","userAuthenticationService", saveService]);
clientModule.service("clientService", ["$resource", "userAuthenticationService", "utilityService", "saveService", clientService]);

export { clientModule };

