"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const pastPregnancyController = function pastPregnancyController($scope, clientService, utilityService, modalService, pastPregnancyService, saveService, userAuthenticationService) {
    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $scope.editingIndex = -1;
        $scope.isEdit = false;
        $scope.subQuestionGroups = [];
        $scope.groups = this.extractGroupsForTheSection("pastPregnanciesSection");
        $scope.allOutcomes = {};
        $scope.sectionHeader = {
            Id: "PregnanciesHeader"
        }
        $scope.childGroup = {
            Name: "Newborn Details",
            Question: "outcome"
        };

        $scope.currentAnswerGroup = null;

        $scope.numberOfFetues = new Array(1);

        // Add and display a message on past pregnancy tab
        // e.g. Have you had miscarriages, abortions, live or still births? If so press Add Pregnancy
        let titleGroup = $scope.allGroups.find(g => g.data.includes(`"groupName":"${$scope.sectionHeader.Id}"`));
        if (titleGroup) {
            Object.assign(titleGroup, JSON.parse(titleGroup.data));
            $scope.title = titleGroup.titleText;
        }

        this.getQuestionGroupswithQuestions();
        if (!$scope.groups[0].questions) return;

        $scope.mainQues = $scope.groups[0].questions[0];
        $scope.mainQuesValues = this.GetArray($scope.mainQues.comboOptions);
        this.createSubQuestion();
        $scope.groupsToDisplay = this.getExistingPregnancyDetails($scope.groups[0].uniqueId);
        //    let temp = [...$scope.groupsToDisplay, ...$scope.groupsToDisplay];
        //    temp =[...temp, ...$scope.groupsToDisplay];
        //     $scope.groupsToDisplay = temp;
    };

    this.createSubQuestion = function createSubQuestion() {
        $scope.subQuestion = {
            title: "Outcome",
            id: "Outcome",
            values: ["Please Select"],
            isRequired: true,
            defaultValue: "Please Select",
            answer: "Please Select"
        };
        $scope.groups[0].childGroups.forEach(group => {
            const reg = new RegExp(/(groupName\\*"):\"(\w*\s*\w*)\"/, "i");
            const capturingGroup = reg.exec(group.data);
            if (!capturingGroup) return;
            const shouldhideRegex = new RegExp(/hideInViewMode\\*":\s*1/, "i");
            if (shouldhideRegex.test(group.data)) return;
            $scope.subQuestion.values.push(capturingGroup[2]);
        });
    };

    this.getExistingPregnancyDetails = function getExistingPregnancyDetails(groupId) {
        $scope.anwserGroups = clientService.getAnswerGroupsFor(groupId);

        return $scope.anwserGroups.map((ansGroup, index) => this.createDisplayGroup(ansGroup, index));
    };


    // Creates tiles for existing pregnancies
    this.createDisplayGroup = function createDisplayGroup(ansGroup, index) {
        let displayGroup = {
            title: ` Pregnancy`,
            id: this.extractUniqueId(ansGroup),
            subGroups: [],
            pregnancyCount: 0
        };
        // Each ansGroup is a pregnancy detail, say 1st pregnancy
        // ansGroup contains subGroups, each subgroup is a new born detail e.g. LiveBirth
        // Then subGroup contains answers
        ansGroup.subGroups.forEach((subGroup) => {
            const displaySubGroup = { 'answers': [] };
            const answerGroupId = this.extractUniqueId(subGroup);
            if (!subGroup.answers || subGroup.answers.length <= 0) {
                const questionGroupId = this.extractQuestionGroupId(subGroup);
                const questionGroup = clientService.allQuestionGroups.find(q => q.data.includes(`"uniqueID":${questionGroupId}`));
                subGroup.summary = displaySubGroup.summary = this.extractGroupName(questionGroup);
                displaySubGroup.questionGroup = questionGroup;
            }
            subGroup.answers.forEach(answer => {
                // Get the question for the answer
                let questionId = this.extractQuestionId(answer);
                let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${questionId}`));
                if (!question) return;
                const questionData = JSON.parse(question.data);

                if (!displayGroup.summary) {
                    const questionGroupId = this.extractQuestionGroupId(question);
                    const questionGroup = clientService.allQuestionGroups.find(q => q.data.includes(`"uniqueID":${questionGroupId}`));
                    subGroup.summary = displaySubGroup.summary = this.extractGroupName(questionGroup);
                    displaySubGroup.questionGroup = questionGroup;

                }

                const questionParentId = this.extractParentQuestionId(question);
                const displaySubGroupAnswer = {
                    id: questionId,
                    data: answer.data,
                    answerId: this.extractUniqueId(answer),
                    answerGroup: answerGroupId,
                    parentId: questionParentId,
                    sortOrder: questionData.sortOrder,
                    title: this.CapitalizeString(questionData.text),//|| this.getParentQuestionText(questionParentId),//or get parent question text
                    answer: `${this.extractAnswer(questionData, answer)} ${this.getUnits(questionData.text)}`
                };
                // if selected question has a parent, e.g. Birth weight as 2 questions lbs and oz
                if (displaySubGroupAnswer.parentId) {
                    displaySubGroupAnswer.multiAnswer = {};
                    displaySubGroupAnswer.multiAnswer[displaySubGroupAnswer.sortOrder] = displaySubGroupAnswer.answer;
                }
                const existingAnswer = displaySubGroupAnswer.parentId ?
                    displaySubGroup.answers.find(a => a.parentId === displaySubGroupAnswer.parentId)
                    : null;
                if (existingAnswer) {
                    existingAnswer.multiAnswer = existingAnswer.multiAnswer || {};
                    existingAnswer.multiAnswer[displaySubGroupAnswer.sortOrder] = displaySubGroupAnswer.answer;
                    existingAnswer.answer = this.setAnswer(existingAnswer);
                    existingAnswer.title = existingAnswer.title || displaySubGroupAnswer.title;
                }
                else
                    displaySubGroup.answers.push(displaySubGroupAnswer);

            });
            if (!displaySubGroup.summary) return;
            if (displaySubGroup.summary != "PregnancyDetails") displayGroup.pregnancyCount++;
            else {
                displaySubGroup.summary = "Complications"
                if (displaySubGroup.answers && displaySubGroup.answers.length > 0) {
                    displaySubGroup.answers = [{
                        id: displaySubGroup.answers[0].id,
                        data: displaySubGroup.answers[0].data,
                        title: "Complications experienced during pregnancy",
                        answer: displaySubGroup.answers.reduce((str, a) => { if (str) str += ", "; str += a.answer; return str; }, "")
                    }];
                }
                else
                    displaySubGroup.hide = true;
            }
            displayGroup.subGroups.push(displaySubGroup);
        });

        this.reorderGroups(displayGroup);
        this.reorderGroups(ansGroup);
        displayGroup.numberOfFetues = this.setFetuesCountText(displayGroup.pregnancyCount);
        return displayGroup;

    }

    // Move complications to the bottom
    this.reorderGroups = function reorderGroups(displayGroup) {
        if (!displayGroup.subGroups || !displayGroup.subGroups.length) return;
        const complicationIndex = displayGroup.subGroups.findIndex(g => g.summary === "Complications");
        if (complicationIndex < 0) return;
        displayGroup.subGroups = utilityService.arrayMove(displayGroup.subGroups, complicationIndex, displayGroup.subGroups.length - 1);
    }

    this.onEdit = function onEdit(answerGroupId) {
        console.log(answerGroupId);
        $scope.subQuestionGroups = [];
        const answerGroup = $scope.groupsToDisplay.find(group => group.id === answerGroupId);
        $scope.editingIndex = $scope.groupsToDisplay.findIndex(group => group.id === answerGroupId);
        $scope.mainQues.Answer = answerGroup.numberOfFetues;
        this.setNumber($scope.mainQues.Answer);

        const originalAnswerGroup = $scope.anwserGroups
            .find(group => group.data && group.data.includes(answerGroupId))
            || answerGroup;

        if (!originalAnswerGroup) return;
        $scope.currentAnswerGroup = angular.copy(originalAnswerGroup);
        $scope.isEdit = true;
    }

    this.onDelete = function onDelete(answerGroupId) {
        console.log(answerGroupId);
        modalService.showConfirmationModal('Are you sure you want to Delete?', 'Delete Existing Pregnancy', () => {
            const index = $scope.groupsToDisplay.findIndex(group => group.id === answerGroupId);
            $scope.groupsToDisplay.splice(index, 1);

        });
    }

    this.onCancel = function onCancel() {
        $scope.isEdit = false;
        $scope.currentAnswerGroup = null;
    };

    this.onSave = function onSave(form) {
        const mainFormElt = angular.element(document.querySelector('[name="pastPregnanciesSectionForm"]'))
        if (mainFormElt) {
            const sc = mainFormElt.scope();
            if (!sc) return;
            const formElt = sc["pastPregnanciesSectionForm"];
            formElt.$setSubmitted(); console.log(formElt.$error);
            //if there is a currentAnswerGroup rather than dirty, get all controls with value
            const controls = (!$scope.currentAnswerGroup) ?
                formElt.$$controls.filter(c => c.$dirty)
                : formElt.$$controls.filter(c => c.$modelValue);
            let transactionData = [];
            const sets = controls.reduce((sets, control) => {
                let controlIdParts = control.$$attr.id.split("_");
                sets[controlIdParts[0]] = sets[controlIdParts[0]] || [];
                sets[controlIdParts[0]].push(control);
                return sets;
            }, {});
            const keys = Object.keys(sets);
            keys.forEach(key => {
                const elements = sets[key];
                //they belong to same subgroup
                let answerGroupId = "";
                elements.forEach(elt => {
                    const attributes = elt.$$attr;
                    if (!answerGroupId) {
                        answerGroupId = attributes.answerGroup ?
                            attributes.answerGroup : clientService.getUniqueIdentifier();
                    }
                    const answerId = attributes.answerId ?
                        attributes.answerId : clientService.getUniqueIdentifier();
                    //get subgroupid
                    //get transactions 
                    let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${attributes.questionId}`));
                    if (!question) {
                        console.log("missing question, ", elt);
                        return;
                    }
                    if (!question.text) Object.assign(question, JSON.parse(question.data));

                    const groupId = utilityService.extractQuestionGroupId(question);
                    const group = clientService.questionGroups.find(q => q.Id === "Past Pregnancy").childGroups.find(q => q.data.includes(`"uniqueID":${groupId}`));
                    group.Name = this.extractGroupName(group);
                    const transactionObject = clientService.createTransactionObject(group, question, answerGroupId, answerId);
                    transactionData.push(transactionObject);
                });
            });


            console.log(transactionData);
            //use the answerGroup in case we are editing
            //if ($scope.currentAnswerGroup) { }
            if (userAuthenticationService.isNewUser) {
                const obj = {
                    'answerId': $scope.currentAnswerGroup.id,
                    'transactions': transactionData
                };
                const index = $scope.groupsToDisplay.findIndex(group => group.id === $scope.currentAnswerGroup.id);
                if (index < 0) clientService.pastPregnancyTransactions.push(obj);
                else clientService.pastPregnancyTransactions.splice(index, 1, obj);
            }

        }

        const index = $scope.groupsToDisplay.findIndex(group => group.id === $scope.currentAnswerGroup.id);
        $scope.groupsToDisplay.splice(index, 1, $scope.currentAnswerGroup);
        $scope.isEdit = false;
    }


    this.onSavePastPregnancy = function onSavePastPregnancy(form) {
        let transactionData = [];
        let displayGroup = { subGroups: [] };
        const mainFormElt = angular.element(document.querySelector('[name="pastPregnanciesSectionForm"]'))
        if (!mainFormElt) {
            $scope.editingIndex = -1;
            $scope.isEdit = false;
            return;
        }
        const sc = mainFormElt.scope();
        if (!sc) return;
        let answerGroupId = $scope.currentAnswerGroup ?
            $scope.currentAnswerGroup.id
            : clientService.getUniqueIdentifier();
        if ($scope.editingIndex < 0) {
            //create an answerGroup
            //transactionData.push(answerGroupTransaction

            const answerGroupTransaction = saveService.createAnswerGroupTransactionObj(answerGroupId,
                "currentPregnancy",
                $scope.groups[0].uniqueId,
                clientService.userId,
                clientService.userId,
                clientService.actionType.insert);
            transactionData.push(answerGroupTransaction);
            displayGroup = answerGroupTransaction;
            displayGroup.subGroups = [];
        }

        const formElt = sc["pastPregnanciesSectionForm"];
        formElt.$setSubmitted(); console.log(formElt.$error);
        if (formElt.$$controls.filter(c => c.$dirty).length < 0) {
            $scope.editingIndex = -1;
            $scope.isEdit = false;
            return;
        }

        const controls = formElt.$$controls.filter(c => c.$modelValue !== null && c.$modelValue !== undefined);

        const sets = controls.reduce((sets, control) => {
            if (!control.$$attr || !control.$$attr.id) return sets;
            let controlIdParts = control.$$attr.id.split("_");
            sets[controlIdParts[0]] = sets[controlIdParts[0]] || [];
            sets[controlIdParts[0]].push(control);
            return sets;
        }, {});

        const keys = Object.keys(sets);
        const fieldKeys = keys.filter(k => !isNaN(k));
        fieldKeys.forEach((key, index) => {
            const elements = sets[key];
            //subQuestionGroup
            const subGroupDetail = sets["Outcome"].find(a => a.$$attr.id.includes(index));
            if (!subGroupDetail) return;
            const subGroupName = subGroupDetail.$modelValue;
            if (!subGroupName || subGroupName === "Please Select") return;
            const subGroup = $scope.groups[0].childGroups.find(g => g.data.includes(`"groupName":"${subGroupName}"`));
            const subGroupId = this.extractUniqueId(subGroup);

            const subAnswerGroupId = clientService.getUniqueIdentifier();
            const subAnswerGroupTransaction = saveService.createAnswerGroupTransactionObj(subAnswerGroupId,
                "currentPregnancy",
                subGroupId,
                answerGroupId,
                clientService.userId,
                clientService.actionType.insert);
            transactionData.push(subAnswerGroupTransaction);
            displayGroup.subGroups.push(subAnswerGroupTransaction);
            const displaySubGroup = displayGroup.subGroups[displayGroup.subGroups.length - 1];
            displaySubGroup.answers = [];
            const filteredElts = elements.reduce((result, control) => {
                if (!control.$$attr || !control.$$attr.id) return result;
                if (result.find(e => e.$$attr.id === control.$$attr.id)) return result;
                result.push(control);
                return result;
            }, []);
            filteredElts.forEach(elt => {
                const attributes = elt.$$attr;
                let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${attributes.questionId}`));
                if (!question) {
                    console.log("missing question, ", elt);
                    return;
                }
                question = angular.copy(question);
                if (!question.text) Object.assign(question, JSON.parse(question.data));
                if (question.hasCombo && elt.$modelValue === "Please Select") return;
                question.uniqueId = question.uniqueId || attributes.questionId;
                question.Answer = elt.$modelValue;

                const groupId = utilityService.extractQuestionGroupId(question);
                const group = clientService.questionGroups.find(q => q.Id === "Past Pregnancy").childGroups.find(q => q.data.includes(`"uniqueID":${groupId}`));
                group.Name = this.extractGroupName(group);
                const uniqueId = clientService.getUniqueIdentifier();
                const transactionObject =
                    saveService.createAnswerTransactionObject(group, question,
                        subGroupId,
                        uniqueId,
                        clientService.userId,
                        clientService.actionType.insert);
                transactionData.push(transactionObject);
                displaySubGroup.answers.push(transactionObject);
            });
        });
        if (userAuthenticationService.isNewUser) {
            const obj = {
                'answerId': answerGroupId,
                'transactions': transactionData
            };
            if ($scope.editingIndex && $scope.editingIndex >= 0) {
                clientService.pastPregnancyTransactions.splice($scope.editingIndex, 1, obj);
            }
            else clientService.pastPregnancyTransactions.push(obj);
        }
        // else clientService.saveTransactions(transactionData);
        let groupToDisplay = this.createDisplayGroup(displayGroup);
        if ($scope.editingIndex >= 0) {
            $scope.groupsToDisplay.splice($scope.editingIndex, 1, groupToDisplay);
            clientService.summaryTabPastPregnancyDetails.splice($scope.editingIndex, 1, groupToDisplay);
        }
        else {
            $scope.groupsToDisplay.push(groupToDisplay);
            clientService.summaryTabPastPregnancyDetails.push(groupToDisplay);
        }
        $scope.editingIndex = -1;
        $scope.isEdit = false;
    }

    this.addPregnancy = function addPregnancy() {
        $scope.currentAnswerGroup = null;
        $scope.editingIndex = -1;
        $scope.isEdit = true;
        $scope.numberOfFetues = new Array(1);
        $scope.mainQues.Answer = $scope.mainQuesValues[0];
        $scope.subQuestionGroups = [];
    }
    this.setNumber = function setNumber(value) {
        $scope.numberOfFetues = new Array($scope.mainQuesValues.indexOf(value) + 1);
    }

    this.setFetuesCountText = function setFetuesCountText(count) {
        return $scope.mainQuesValues[count - 1];
    }

    this.setAnswer = function setAnswer(existingAnswer) {
        if (!existingAnswer || !existingAnswer.multiAnswer) return existingAnswer.answer;

        let ans = "";
        const keys = Object.keys(existingAnswer.multiAnswer);
        keys.sort();
        keys.forEach(key => {
            if (ans) ans += " ";
            ans += existingAnswer.multiAnswer[key];
        });

        return ans;
    }

    this.ordinalSuffixOf = function ordinalSuffixOf(index) {
        return utilityService.ordinalSuffixOf(index);
    }


    this.getParentQuestionText = function getParentQuestionText(parentId) {
        if (!parentId) return null;
        const quesData = this.getQuestionData(parentId);
        return quesData ? quesData.text : null;
    }

    this.getQuestionData = function getQuestionData(questionId) {
        let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${questionId}`));
        if (!question) return null;
        return JSON.parse(question.data);
    }

    this.getFetusSummary = function getFetusSummary(fetusDetails, index) {
        return utilityService.getFetusSummary(fetusDetails, index);
    };

    this.init();
};

export { pastPregnancyController };