const pregnancySelectionController = function pregnancySelectionController($scope) {
    this.init = function init() {
       
    };

   
    this.init();
};

export { pregnancySelectionController };