"use strict";
import generator from "generate-password";

const utilityService = function utilityService() {

    const titleTextReg = new RegExp(/(titleText\\*"):""(.*?)""/, "i");
    const uniqueIdReg = new RegExp(/(uniqueID\\*"):([0-9]+)/, "i");
    const uniqueIdStrReg = new RegExp(/(uniqueIDStr\\*"):([0-9]+)/, "i");
    const questionGroupReg = new RegExp(/("questionGroup\\*"):([0-9]+)/, "i");
    const answerGroupReg = new RegExp(/("answerGroup\\*"):([0-9]+)/, "i");
    const groupNameReg = new RegExp(/(groupName\\*"):"(.*?)"/, "i");
    const questionReg = new RegExp(/(question\\*"):([0-9]+)/, "i");
    const parentQuestionIdReg = new RegExp(/(parentPrintQuestion\\*"):([0-9]+)/, "i");

    this.init = function init() { };

    this.getQuestionType = function getQuestionType(question) {

        if (question.isLabel) return "label";
        if (question.hasTextBox && !question.multiButtonType) return "text";
        if (question.hasDateTime && question.hideIcon) return "dateTimeWithNoCalendarIcon";
        if (question.hasDateTime) return "dateTime";
        if (question.hasYesNo && question.hasCommentBox) return "yesNoWithComment";
        if (question.hasYesNo && !question.segmentedControlValues) return "yesNo";
        if (question.hasYesNo && question.segmentedControlValues) return "yesNoWithCustomValues";
        if (question.hasCombo) return "combo";
        if (question.multiButtonType === 1) return "mbt1";
        if (question.numberResponse) return "number";
    };


    this.constructAnwserGroups = function constructAnwserGroups(answerJson) {
        const allAnswerGroups = answerJson.filter(a => a.objectName === "2");
        const allAnswers = answerJson.filter(a => a.objectName === "1");

        allAnswerGroups.forEach(group => {
            let id = this.extractUniqueId(group, uniqueIdReg);
            group.answers = allAnswers.filter(q => q.data.includes(id));
        });
        allAnswerGroups.forEach(group => {
            let id = this.extractUniqueId(group, uniqueIdReg);
            group.subGroups = allAnswerGroups.filter(q => q.data.includes(`"parentAnswerGroup":${id}`));
        });
        return allAnswerGroups;
    };

    this.GetDefaultValue = (question) => {
        return this.getTypeCastedValue(question, question.defaultValue);
    };

    this.getTypeCastedValue = function getTypeCastedValue(question, value) {
        if (!question.uniqueId && question.data) {
            Object.assign(question, JSON.parse(question.data));
        }

        if (question.hasYesNo && !question.segmentedControlValues) {
            if (value === null || value === undefined) return value;
            const regex = new RegExp(/TRUE|1/, "i");
            return regex.test(value || false);
        }
        if (question.hasDateTime && !!value) {
            if (typeof value === "string" && value.toLowerCase() === "current time")
                return Moment(new Date()).format("MM/DD/YYYY");//return getTodayDate();
            if (isNaN(Date.parse(value))) return null;
            return Moment(new Date(value)).format("MM/DD/YYYY");
        }
        return value;
    };

    this.ordinalSuffixOf = function ordinalSuffixOf(i) {
        var j = i % 10,
            k = i % 100;
        if (j == 1 && k != 11) {
            return i + "st";
        }
        if (j == 2 && k != 12) {
            return i + "nd";
        }
        if (j == 3 && k != 13) {
            return i + "rd";
        }
        return i + "th";
    }
    
    this.getQuestionText = function getQuestionText(q) {
        return q.questionName || q.text || q.textInViewMode || q.waterMark || "";
    };
    
    this.extractUniqueId = function extractUniqueId(group) {
        return extractValue(group, uniqueIdReg) || extractValue(group, uniqueIdStrReg);
    };

    this.extractTitleText = function extractTitleText(group) {
        return extractValue(group, titleTextReg);
    };

    this.extractQuestionGroupId = function extractQuestionGroupId(group) {
        return extractValue(group, questionGroupReg);
    };

    this.extractAnswerGroupId = function extractAnswerGroupId(group) {
        return extractValue(group, answerGroupReg);
    };

    this.extractGroupName = function extractGroupName(group) {
        return extractValue(group, groupNameReg);
    };

    this.extractQuestionId = function extractQuestionId(group) {
        return extractValue(group, questionReg);
    };

    this.extractParentQuestionId = function extractParentQuestionId(question) {
        return extractValue(question, parentQuestionIdReg);
    };

    this.generatePassword = function generatePassword() {
        // Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        return generator.generate({
            length: 10,
            numbers: true
        });
    };

    this.arrayMove = function arrayMove(arr, old_index, new_index) {
        while (old_index < 0) {
            old_index += arr.length;
        }
        while (new_index < 0) {
            new_index += arr.length;
        }
        if (new_index >= arr.length) {
            var k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr;
    };

    this.calculateBMI = function calculateBMI(weight, heightInFeet, heightInInches) {
        if (!weight || !heightInFeet) return null;
        let heightInInchesValue = parseFloat(heightInFeet) * 12;
        if (heightInInches) heightInInchesValue += parseFloat(heightInInches);
        return parseInt(Math.round((weight / (heightInInchesValue * heightInInchesValue)) * 703.0));
    };

    this.getWeeksGestation = function getWeeksGestation(estimatedDueDate) {
        if (!estimatedDueDate) return;
        const conceptionDate = addDays(estimatedDueDate, 40 * 7);
        const diff = (new Date(conceptionDate - Date.now()).getTime() / 1000) * -1;
        const weeksPregnant = diff / 604800.0;
        const justWeeks = parseInt(Math.floor(weeksPregnant));
        let days = parseInt(diff - (justWeeks * 604800));
        days = days / (60 * 60 * 24);
        return justWeeks + (days / 10);
    };

    this.getWeeksPostpartum = function getWeeksPostpartum(actualDeliveryDate) {
        const diff = (Date.now() - actualDeliveryDate).getTime() / 1000;
        if (diff < 0) return;
        const weeksPostPartum = diff / 604800.0;
        const justWeeks = parseInt(Math.floor(weeksPostPartum));
        let days = parseInt(diff) - (justWeeks * 604800);
        days = days / (60 * 60 * 24);
        return justWeeks + (days / 10);
    };

    this.calculateEDD = function calculateEDD(basedOnDate) {
        if (!basedOnDate.Answer || !(moment(new Date(basedOnDate.Answer)).isValid())) return null;

        if (basedOnDate.questionName != "lmpDate" &&
            basedOnDate.questionName != "conceptionDate" &&
            basedOnDate.questionName != "ovulation date") 
            return moment(new Date(basedOnDate.Answer)).format("MM/DD/YYYY");

        let weeks = (basedOnDate.questionName === "lmpDate") ? 40 : 38;
        const edd = addDays(basedOnDate.Answer, weeks * 7);
        return moment(new Date(edd)).format("MM/DD/YYYY");
    };

    this.getFetusSummary = function getFetusSummary(fetusDetails, index) {
        if (!fetusDetails || fetusDetails.summary === "Complications") return null;
        let summary = `${this.ordinalSuffixOf(index)} Fetus : `;
        summary += `${fetusDetails.summary} `;
        summary += (fetusDetails.summary === "Live Birth") ? this.liveBirthSummary(fetusDetails)
            : this.otherOutcomeSummary(fetusDetails);
        return summary;
    };

    this.liveBirthSummary = function liveBirthSummary(fetusDetails) {
        let summary = "delivered ";
        const dob = fetusDetails.answers.find(a => a.title.includes("Date Of"));
        if (dob) summary += `on ${moment(new Date(dob.answer)).format("MM/YY")} `;
        const gesAge = fetusDetails.answers.find(a => a.title.includes("Gestation"));
        if (gesAge) summary += `at ${gesAge.answer} pregnant.`;
        return summary;
    };

    this.otherOutcomeSummary = function otherOutcomeSummary(fetusDetails){
        let summary = "";
        const dob = fetusDetails.answers.find(a => a.title.includes("Date Of"));
        if (dob) summary += `on ${moment(new Date(dob.answer)).format("MM/YY")} `;
        const gesAge = fetusDetails.answers.find(a => a.title.includes("Wks Pregnant"));
        if (gesAge) summary += `at ${gesAge.answer} weeks pregnant.`;
        return summary;
    };

    this.CapitalizeString = (str) => {
        if (!str) return "";
        if (str.includes("~")) str = str.split("~")[0];
        if (!str.trim()) return "";
        return str.trim().split(/\s+/).map(w => w[0].toUpperCase() + w.slice(1)).join(' ');
    };

    this.getUnits = function getUnits(str) {
        if (!str) return "";
        return str.includes("~") ? str.split("~")[1] : "";
    }

    function extractValue(object, reg) {
        let capturingGroups = reg.exec(object.data);
        if (!capturingGroups) return;
        return capturingGroups[2];
    };

    function addDays(date, days) {
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }

    this.init();
};

export { utilityService };