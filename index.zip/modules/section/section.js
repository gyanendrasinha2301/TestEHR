"use strict";

import "../controls/controls";
import "../multiButtonType4/multiButtonType4";
import "../multiButtonType2/multiButtonType2";
import "../questionGroup/questionGroup";

import { sectionController } from "./controllers/sectionController";
import { ehrSectionDirective } from "./directives/ehrSectionDirective";


const sectionModule = angular.module("ehr.section", ["ehr.controls", "ehr.mbt4", "ehr.mbt2", "ehr.questiongroup"]);

sectionModule.controller("sectionController", ["$scope", sectionController]);
sectionModule.directive("ehrSection", [ehrSectionDirective]);

export { sectionModule };