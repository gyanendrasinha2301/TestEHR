"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const healthSectionController = function healthSectionController($scope, clientService, utilityService) {

    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $scope.groups = this.extractGroupsForTheSection("healthSection");
        // $scope.groups = [{
        //     Id: "FamilyHistory",
        //     Title: "Your Family History",
        //     Name: "Family History",
        //     Section: "healthSection",
        //     IsOpen: true
        // },
        // {
        //     Id: "health",
        //     Title: "Your Health",
        //     Name: "Your History",
        //     Section: "healthSection",
        //     IsOpen: true
        // },
        // {
        //     Id: "Medications",
        //     Title: "Medications",
        //     Name:"MedicationStatus",
        //     Section: "healthSection",
        //     IsOpen: true
        // },
        // /**subsection */
        // // {
        // //     Id: "LifeStyle",
        // //     Title: "Life Style",
        // //     IsOpen: true
        // // },
        // {
        //     Id: "GynecologicHistory",
        //     Title: "Gynecologic History",
        //     Name: "gynHistory",
        //     Section: "healthSection",
        //     IsOpen: true
        // }
        // /**subsection */
        // // {
        // //     Id: "SexualHistory",
        // //     Title: "Sexual History",
        // //     IsOpen: true
        // // },
        // ];

        this.getQuestionGroupswithQuestions();

        const historyGroup = $scope.groups.find(g => g.Name === "Your History");
        if (!historyGroup) return;
        const bmiQues = historyGroup.questions.find(q => q.Title === "BMI");
        if (!bmiQues) return;

        const weightQues = historyGroup.questions.find(q => q.Title === "Current Weight");
        if (!weightQues) return;
        const heightQues = historyGroup.questions.find(q => q.questionName === "currentHeightHealth");
        if (!heightQues) return;
        const heightInFeetQues = heightQues.printQuestions.find(q => q.questionName === "heightInFeetHealth");
        const heightInInchesQues = heightQues.printQuestions.find(q => q.questionName === "heightInInchesHealth");

        const updateBMI = () => {
            bmiQues.Answer = utilityService.calculateBMI(weightQues.Answer, heightInFeetQues.Answer, heightInInchesQues.Answer);
        };
        if (!heightInFeetQues || !heightInInchesQues) return;
        $scope.$watch(() => weightQues.Answer, () => updateBMI());
        $scope.$watch(() => heightInFeetQues.Answer, () => updateBMI());
        $scope.$watch(() => heightInInchesQues.Answer, () => updateBMI());
    };

    this.init();
};

export { healthSectionController };