"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";
import { pastPregnancyController } from "../../pastPregnancySection/controllers/pastPregnancyController";
const summaryController = function summaryController($scope, clientService, utilityService, userAuthenticationService) {
    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $.notify({ icon: 'fa fa-area-chart', message: "Analyzing answers.." });
        $scope.questions = $scope.allQuestionGroups.reduce((questions, group) => {
            let quesWithAnswers = group.questions.filter(ques => !!ques.Answer);
            questions = [...questions, ...quesWithAnswers];
            return questions;
        }
            , []);
        if (userAuthenticationService.isNewUser) {
            $scope.allGroups = this.mapAnswerFromQuestionGroups(clientService.allQuestionGroups);
            $.notifyClose();
            return;
        }
        $scope.allAnswerGroups = this.getAllAnwserGroups();
        $scope.allAnswerGroups.$promise.then(() => {
            $scope.allGroups = this.mapAnswersToQuestions(clientService.answerGroupsWithAnswers);
        }).
            finally(() => { $.notifyClose(); });
    };

    this.getAllAnwserGroups = function getAllAnwserGroups() {
        const guid = userAuthenticationService.sessionToken;
        const loginParams = userAuthenticationService.getLoginParams()
        const allAnswersResource = clientService.getClientAnswers(guid, loginParams.uniqueid);
        return allAnswersResource;
    }

    //Function to create summary in case of new user
    this.mapAnswerFromQuestionGroups = function mapAnswerFromQuestionGroups(allQuestionGroups) {
        const groupsToDisplay = [];
        const pastPregnanacies = [];
        clientService.reqQuestionGroups.forEach(requiredGroup => {
            const group = allQuestionGroups
                .find(g => g.data.includes(`"groupName":"${requiredGroup.Name}"`))
            if (!group) return;
            const groupId = this.extractUniqueId(group);

            if (!group || !group.questions) return;
            let displayGroup = {
                id: groupId,
                title: requiredGroup.Title,
                answers: []
            };
            if (displayGroup.title === "Past Pregnancy") {
                return;
            }
            group.questions.forEach(question => {
                if (question.Answer === undefined || question.Answer === null) return;
                this.fillDetailsFromQuestionsToGroup(question, displayGroup);
            });
            displayGroup.answers.sort((a, b) => this.compare(a, b));
            groupsToDisplay.push(displayGroup);
        });

        if (clientService.summaryTabPastPregnancyDetails && clientService.summaryTabPastPregnancyDetails.length > 0) {
            const pastPregnanacies = angular.copy(clientService.summaryTabPastPregnancyDetails);
            pastPregnanacies.forEach((pregnancyGroup, index) => {
                pregnancyGroup.title = `${utilityService.ordinalSuffixOf(index + 1)} Pregnancy`;
            });
            return [...groupsToDisplay, ...pastPregnanacies];
        }
        return groupsToDisplay;
    };

    this.fillDetailsFromQuestionsToGroup = function fillDetailsFromQuestionsToGroup(question, displayGroup) {
        if (question.subQues && Object.keys(question.subQues).length) {
            Object.keys(question.subQues).forEach(key => {
                if (question.Answer === null || question.Answer === undefined) return;
                if (question.Answer.toString() !== key.toString()) return;
                question.subQues[key].forEach(q =>
                    this.fillDetailsFromQuestionsToGroup(q, displayGroup));
            });
        }
        if (question.multiButtonType === 4 || question.multiButtonType === 2) {
            this.fillDetailsForMultiButtonType(question, displayGroup);
        }
        else {
            const questionData = JSON.parse(question.data);
            if (questionData.hideInViewMode) return;
            const ans = question.Answer;//this.extractAnswer(questionData, question.Answer);
            const comment = question.comment;
            if (ans === undefined
                || ans === null
                || ans === "" || (typeof (ans) === "string" && ans.trim() === "")
                || (question.type === "combo" && (ans === "Please Select" || ans === "Select"))) return;

            displayGroup.answers.push({
                id: question.Id,
                title: this.getTitle(questionData),
                answer: `${this.summaryAnswer(questionData, ans, comment)} ${this.getUnits(questionData.text)}`,
                sortOrder: questionData.sortOrder
            });

        }
        return displayGroup;
    };

    this.fillDetailsForMultiButtonType = function fillDetailsForMultiButtonType(question, displayGroup) {
        if (!question.Answer || Object.keys(question.Answer).length <= 0) return;
        displayGroup.multiButtonGroups = displayGroup.multiButtonGroups || {};
        displayGroup.subGroups = displayGroup.subGroups || [];

        const questionGroupId = utilityService.extractQuestionGroupId(question);
        displayGroup.multiButtonGroups[questionGroupId] = displayGroup.multiButtonGroups[questionGroupId] || { subGroups: [] };
        displayGroup.multiButtonGroups[questionGroupId].summary = question.Title || question.text;


        Object.keys(question.Answer).forEach(key => {
            const answerList = question.Answer[key];
            if (!answerList) return;

            answerList.forEach(selectedChildGroup => {
                const subDisplayGroup = {};
                //subGroup.name = key;
                subDisplayGroup.answers = [];

                selectedChildGroup.questions.forEach(ques => {

                    subDisplayGroup.answers.push({
                        title: this.getTitle(ques),
                        answer: (ques.type === "label") ? ques.label : ques.Answer
                    });
                    if (ques.subQues && Object.keys(ques.subQues).length > 0) {
                        Object.keys(ques.subQues).forEach(key => {
                            const q = ques.subQues[key];
                            const temp = ({
                                title: this.getTitle(q),
                                answer: (q.type === "label") ? q.label : q.Answer
                            });
                            if (!temp.title || !temp.answer) return;
                            subDisplayGroup.answers.push(temp);
                        });
                    }
                });
                if (subDisplayGroup.answers.length > 0)
                    displayGroup.multiButtonGroups[questionGroupId].subGroups.push(subDisplayGroup);

            });

        });
    };

    this.pastPregnanciesDetailsForNewUser = function pastPregnanciesDetailsForNewUser(displayGroup) {

    };

    this.mapAnswersToQuestions = function mapAnswersToQuestions(allAnswerGroups) {
        let answerGroups = angular.copy(allAnswerGroups);
        answerGroups = answerGroups.filter(ag => !ag.isSubGroup);

        const groupsToDisplay = [];
        const pastPregnanacies = [];
        answerGroups.forEach(answerGroup => {
            let questionGroupId = this.extractQuestionGroupId(answerGroup);
            let questionGroup = clientService.allQuestionGroups.find(group => group.data.includes(`"uniqueID":${questionGroupId}`));
            const requiredGroup = clientService.reqQuestionGroups
                .find(g => questionGroup.data.includes(`"groupName":"${g.Name}"`))
            if (!requiredGroup) return;
            if (!questionGroup || !questionGroup.questions) return;

            let displayGroup = {
                id: questionGroupId,
                title: requiredGroup.Title,//utilityService.extractTitleText(questionGroup),
                answers: []
            };

            //extracting out past pregnancies and treating them seperately
            if (displayGroup.title === "Past Pregnancy") {
                displayGroup.answerGroup = answerGroup;
                pastPregnanacies.push(displayGroup);
                return;
            }
            answerGroup.answers.forEach(answer => {
                this.fillDetailsInGroup(answer, displayGroup);
            });
            if (answerGroup.subGroups) {
                answerGroup.subGroups.forEach(subGroup => {
                    displayGroup.subGroups = displayGroup.subGroups || [];
                    displayGroup.subGroups = displayGroup.subGroups || {};
                    const subGroupData = JSON.parse(subGroup.data);
                    const questionGroupId = utilityService.extractQuestionGroupId(subGroup);
                    const subDisplayGroup = {
                        name: subGroupData.name,
                        questionGroupId: questionGroupId,
                        answers: []
                    };
                    displayGroup.multiButtonGroups = displayGroup.multiButtonGroups || {};
                    subGroup.answers.forEach(answer => { this.fillDetailsInGroup(answer, subDisplayGroup); });
                    subDisplayGroup.answers.sort((a, b) => this.compare(a, b));
                    if (displayGroup.multiButtonGroups[questionGroupId] && displayGroup.multiButtonGroups[questionGroupId].subGroups.length > 0) {
                        displayGroup.multiButtonGroups[questionGroupId].subGroups.push(subDisplayGroup);
                        return;
                    }

                    //verify if it a multiButtonType group                  
                    const subQuesGroup = clientService.getQuestionGroupById(questionGroupId);
                    const subGroupName = utilityService.extractGroupName(subQuesGroup);
                    if (!subGroupName) {
                        displayGroup.subGroups.push(subDisplayGroup);
                        return;
                    }
                    const parentQuestion = clientService.getQuestionByChildGroupName(subGroupName);
                    if (!parentQuestion) {
                        displayGroup.subGroups.push(subDisplayGroup);
                        return;
                    }
                    displayGroup.multiButtonGroups[questionGroupId] = displayGroup.multiButtonGroups[questionGroupId] || { subGroups: [] };

                    displayGroup.multiButtonGroups[questionGroupId].summary = parentQuestion.Title || parentQuestion.text;
                    displayGroup.multiButtonGroups[questionGroupId].subGroups.push(subDisplayGroup);
                });
            }

            if (!(displayGroup.answers.length || (displayGroup.subGroups && displayGroup.subGroups.some(sg => sg.answers))
                || (displayGroup.multiButtonGroups && Object.keys(displayGroup.multiButtonGroups).length > 0)
            )) return;

            displayGroup.answers.sort((a, b) => this.compare(a, b));
            if (displayGroup.subGroups)
                displayGroup.subGroups.forEach(subgroup =>
                    subgroup.answers.sort((a, b) => this.compare(a, b)));
            if ((displayGroup.answers && displayGroup.answers.length > 0
                && displayGroup.answers.some(a => !!a.answer))
                || (displayGroup.subGroups && displayGroup.subGroups.length > 0))
                groupsToDisplay.push(displayGroup);
        });

        if (!pastPregnanacies || pastPregnanacies.length <= 0) return groupsToDisplay;
        //Working on past Pregnancies
        const pastPregnancyGroups = this.getExistingPregnancyDetails(pastPregnanacies[0].id);
        return [...groupsToDisplay, ...pastPregnancyGroups];

    };


    this.fillDetailsInGroup = function fillDetailsInGroup(answer, displayGroup) {
        let questionId = this.extractQuestionId(answer);
        let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${questionId}`));
        if (!question) return;
        const questionData = JSON.parse(question.data);
        if (questionData.hideInViewMode) return;
        const ans = this.extractAnswer(questionData, answer);
        let comment = null;
        if (questionData.hasYesNo && questionData.hasCommentBox) {
           comment = question.comment;
        }

        displayGroup.answers.push({
            id: questionId,
            title: this.getTitle(questionData),
            answer: (questionData.multiButtonType || !ans)
                ? null
                : `${this.summaryAnswer(questionData, ans, comment)} ${this.getUnits(questionData.text)}`,
            sortOrder: questionData.sortOrder
        });

        return displayGroup;
    };

    this.summaryAnswer = function summaryAnswer(questionData, answer, comment) {
        const ans = this.getTypeCastedValue(questionData, answer);
        if (questionData.hasYesNo) {
            let modifiedAns = ans ? "Yes" : "No";
            if (questionData.hasCommentBox) modifiedAns += `, ${comment}`;
            return modifiedAns;
        }
        return ans;
    };

    this.getExistingPregnancyDetails = function getExistingPregnancyDetails(groupId) {
        const anwserGroups = clientService.getAnswerGroupsFor(groupId);

        return anwserGroups.map((ansGroup, index) => {
            let displayGroup = {
                title: `${utilityService.ordinalSuffixOf(index + 1)} Pregnancy`,
                id: this.extractUniqueId(ansGroup),
                subGroups: [],
                pregnancyCount: 0
            };
            ansGroup.subGroups.forEach((subGroup) => {
                const displaySubGroup = { 'answers': [] };
                subGroup.answers.forEach(answer => {

                    let questionId = this.extractQuestionId(answer);
                    let question = clientService.allQuestions.find(q => q.data.includes(`"uniqueID":${questionId}`));
                    if (!question) return;
                    const questionData = JSON.parse(question.data);

                    if (!displayGroup.summary) {
                        const questionGroupId = this.extractQuestionGroupId(question);
                        const questionGroup = clientService.allQuestionGroups.find(q => q.data.includes(`"uniqueID":${questionGroupId}`));
                        displaySubGroup.summary = this.extractGroupName(questionGroup);
                        displaySubGroup.questionGroup = questionGroup;

                    }
                    const displaySubGroupAnswer = {
                        id: questionId,
                        data: answer.data,
                        parentId: this.extractParentQuestionId(question),
                        sortOrder: questionData.sortOrder,
                        title: this.CapitalizeString(questionData.text),
                        answer: `${this.extractAnswer(questionData, answer)} ${this.getUnits(questionData.text)}`
                    };
                    if (displaySubGroupAnswer.parentId) {
                        displaySubGroupAnswer.multiAnswer = {};
                        displaySubGroupAnswer.multiAnswer[displaySubGroupAnswer.sortOrder] = displaySubGroupAnswer.answer;
                    }
                    const existingAnswer = displaySubGroupAnswer.parentId ?
                        displaySubGroup.answers.find(a => a.parentId === displaySubGroupAnswer.parentId)
                        : null;
                    if (existingAnswer) {
                        existingAnswer.multiAnswer = existingAnswer.multiAnswer || {};
                        existingAnswer.multiAnswer[displaySubGroupAnswer.sortOrder] = displaySubGroupAnswer.answer;
                        existingAnswer.answer = this.setAnswer(existingAnswer);
                        existingAnswer.title = existingAnswer.title || displaySubGroupAnswer.title;
                    }
                    else
                        displaySubGroup.answers.push(displaySubGroupAnswer);

                });
                if (!displaySubGroup.summary) return;
                if (displaySubGroup.summary != "PregnancyDetails") {
                    displayGroup.pregnancyCount++;
                    displaySubGroup.summaryText = utilityService.getFetusSummary(displaySubGroup, displayGroup.pregnancyCount);
                }
                else {
                    displaySubGroup.summary = "Complications"
                    displaySubGroup.answers = [{
                        id: displaySubGroup.answers[0].id,
                        data: displaySubGroup.answers[0].data,
                        title: "Complications experienced during pregnancy",
                        answer: displaySubGroup.answers.reduce((str, a) => { if (str) str += ", "; str += a.answer; return str; }, "")
                    }];

                }
                displayGroup.subGroups.push(displaySubGroup);
            });

            displayGroup.numberOfFetues = this.setFetuesCountText(displayGroup.pregnancyCount);
            return displayGroup;
        });
    };

    this.setFetuesCountText = function setFetuesCountText(count) {
        if ($scope.mainQuesValues) return $scope.mainQuesValues[count - 1];
        let group = clientService.allQuestionGroups.find(g => g.data.includes(`"groupName":"Pregnancy"`))
        if (!group || !group.questions) return;
        let mainQues = group.questions.find(q => q.data.includes("number of fetuses"));
        if (!mainQues) return;
        Object.assign(mainQues, JSON.parse(mainQues.data));
        $scope.mainQuesValues = this.GetArray(mainQues.comboOptions);
        return $scope.mainQuesValues[count - 1];
    };

    this.getTitle = function getTitle(questionData) {
        const text = questionData.Title || questionData.text || questionData.questionName || questionData.textInViewMode || questionData.waterMark;
        return this.CapitalizeString(text);
    }

    this.setAnswer = function setAnswer(existingAnswer) {
        if (!existingAnswer || !existingAnswer.multiAnswer) return existingAnswer.answer;

        let ans = "";
        const keys = Object.keys(existingAnswer.multiAnswer);
        keys.sort();
        keys.forEach(key => {
            if (ans) ans += " ";
            ans += existingAnswer.multiAnswer[key];
        });

        return ans;
    };

    this.getMultiButtonGroupKeys = function getMultiButtonGroupKeys(group) {
        return group.multiButtonGroups ? Object.keys(group.multiButtonGroups) : [];
    };

    this.CalculateControlWidth = function CalculateControlWidth(answer) {
        if (!answer) return 3;
        if (answer.length <= 25) return 3;
        if (answer.length <= 50) return 6;
        return 12;
    };
    this.init();
}

export { summaryController };