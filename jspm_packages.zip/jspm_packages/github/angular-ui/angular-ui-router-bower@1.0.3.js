define(["github:angular-ui/angular-ui-router-bower@1.0.3/release/angular-ui-router.js"], function(main) {
  return main;
});