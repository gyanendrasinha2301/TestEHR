/* */ 
"format cjs";
require('./angular-aria');
module.exports = 'ngAria';
