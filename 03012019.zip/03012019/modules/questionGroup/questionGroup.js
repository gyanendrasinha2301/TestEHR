"use strict";

import "../controls/controls";
import "../multiButtonType4/multiButtonType4";
import "../multiButtonType2/multiButtonType2";

import { questionGroupController } from "./controllers/questionGroupController";
import { ehrQuestionGroupDirective } from "./directives/ehrQuestionGroupDirective";

const questionGroupModule = angular.module("ehr.questiongroup", ["ehr.controls", "ehr.mbt4", "ehr.mbt2"]);

questionGroupModule.controller("questionGroupController", ["$scope", questionGroupController]);
questionGroupModule.directive("ehrQuestionGroup", [ehrQuestionGroupDirective]);

export { questionGroupModule };