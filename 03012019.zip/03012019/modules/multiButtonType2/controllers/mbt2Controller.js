"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const mbt2Controller = function mbt2Controller($scope, clientService, utilityService) {

    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        if (!$scope.ques || !$scope.ques.childAnswerGroup) return;
        $scope.subQuestionGroup = clientService.getQuestionGroupByName($scope.ques.childAnswerGroup);
        $scope.subQuestionGroup.questions = this.extractGroupQuestions($scope.subQuestionGroup, true);
        $scope.shouldDisplay = false;
        $scope.buttonText = $scope.ques.comboOptions;
        $scope.ques.Answer = [];
        //get answerGroup for $scope.ques
        if(!clientService.clientAnswers) return;
        const answerGroupsForQues = clientService.clientAnswers.GetClientResult.filter(a => a.data.includes($scope.subQuestionGroup.uniqueId));
        if (!answerGroupsForQues || answerGroupsForQues.length <= 0) return;
        $scope.ques.Answer = answerGroupsForQues.reduce((result, answerGroup) => {
            const group = angular.copy($scope.subQuestionGroup);
            group.questions.forEach(question => this.setQuestionProperties(question));
            answerGroup.answers.forEach(ans => {
                const qId = this.extractQuestionId(ans);
                const question = group.questions.find(q => q.data.includes(`"uniqueID":${qId}`));
                if (!question) return;
                question.Answer = clientService.extractAnswer(question, ans);
            });
            result.push(group);
            return result;
        }, []);
        const derigester = $scope.$watch(() => $scope.ques.Answer, (newVal, oldVal) => {
            if(newVal === oldVal) return;
            //derigester();
            $scope.ques.isAnswerEdited = true;
        });

        /*
                const answerGroupId = utilityService.extractAnswerGroupId(answerGroupsForQues[0]);
                if (!answerGroupId) return;
                const aGroup = clientService.getAnswerById(answerGroupId);
                //get AnswerGroup id from first value
                //get the answer with uniqueid as answergroup id        
                //const answerGroups = clientService.answerGroupsWithAnswers.filter(a => a.data.includes(`${option}`));
                if (!aGroup.subGroups || aGroup.subGroups.length <= 0) return;
                $scope.ques.Answer =
                    aGroup.subGroups.reduce((result, answerGroup) => {
                        const group = angular.copy($scope.subQuestionGroup);
                        group.questions.forEach(question => this.setQuestionProperties(question));
                        answerGroup.answers.forEach(ans => {
                            const qId = this.extractQuestionId(ans);
                            const question = group.questions.find(q => q.data.includes(`"uniqueID":${qId}`));
                            if (!question) return;
                            question.Answer = clientService.extractAnswer(question, ans);
                        });
                        result.push(group);
                        return result;
                    }, []);*/
    };

    this.toggleDisplayGroups = function toggleDisplayGroups() {
        $scope.shouldDisplay = !$scope.shouldDisplay;
        if (!$scope.groups) this.addNewRow();
    }

    this.addNewRow = function addNewRow() {
        $scope.groups = $scope.groups || [];
        const group = angular.copy($scope.subQuestionGroup);
        group.questions.forEach(question => {
            this.setQuestionProperties(question);
        });
        $scope.ques.Answer = $scope.ques.Answer || [];
        $scope.ques.Answer.push(group);
        $scope.groups = $scope.ques.Answer;
    };

    this.removeRow = function removeRow(index) {
        $scope.groups.splice(index, 1);
    };

    this.setQuestionProperties = function setQuestionProperties(question) {
        question.Id = `${question.Id}`;
        question.width = question.isLabel ? 2 : 3;
        question.hideIcon = "calendar";
        question.type = utilityService.getQuestionType(question);
    };

    this.getAnswerCount = function getAnswerCount() {
        const answers = $scope.ques.Answer;
        return answers && answers.length > 0 ? `(${answers.length}) ` : "";
    }
    this.init();
};

export { mbt2Controller };