"use strict";

const pastPregnancyService = function pastPregnancyService() {
this.init = function init(){};

this.init();

 };

export { pastPregnancyService };