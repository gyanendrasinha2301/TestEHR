"use strict";

function ehrLoaderDirective(){
    return {
        templateUrl : "modules/common/templates/loader.html"    
    };    
};

export {ehrLoaderDirective};