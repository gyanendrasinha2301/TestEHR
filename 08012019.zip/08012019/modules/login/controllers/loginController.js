"use strict";

const loginController = function loginController($scope, $state, modalService, clientService, loginService, userAuthenticationService) {
    this.init = function init() {
        const existingPopUp = angular.element(".modal");
        if (existingPopUp && existingPopUp.scope())
            existingPopUp.scope().$dismiss();

        $scope.htmlTitle = "Mobile Midwife EHR";
        $scope.title = "Mobile Midwife EHR";

        $scope.welcomeNote = "Welcome";
        $scope.shouldShowSubMsg = false;
        $scope.username = null;
        $scope.password = null;
        $scope.stateParams = $state.params;
        if (!$scope.stateParams.guid) {
            modalService.showMessageModal("Invalid URL. Please verify the internet link is accurate and try again.", "Information Missing", false);
            return;
        }
        if (!$scope.stateParams.uniqueid) {

            const midWifeInfo = loginService.getEHR($scope.stateParams.guid);
            midWifeInfo.$promise.then((info) => {
                if (info.errorReport && info.errorReport.ErrorMessage) {
                    modalService.showMessageModal(info.errorReport.ErrorMessage, "Error", true);
                    return;
                }
                userAuthenticationService.sessionToken = info.sessionToken;
                userAuthenticationService.practiceName = info.practicename;
                if (info.practicename) {
                    $scope.practiceName = `${info.practicename}`;
                    document.title = `Welcome to ${info.practicename}`;
                }
                userAuthenticationService.setLoginParams($scope.stateParams.guid);
                userAuthenticationService.isNewUser = true;
                $.notify({ icon: 'fa fa-user-plus', message: "Initiating application for new user" }, { type: "warning" });

                $state.go("main");
            }).catch(() => {
                modalService.showMessageModal("Unable to initiate application for a new user. Please try again.", "Error", true);
            });
        }
        else {
            const clientInfoResource = loginService.getClientInfo($scope.stateParams.guid, $scope.stateParams.uniqueid);
            clientInfoResource.$promise.then((info) => {
                if (info.errorReport && info.errorReport.ErrorMessage) {
                    modalService.showMessageModal(info.errorReport.ErrorMessage, "Error", false);
                    return;
                }
                $scope.welcomeNote = `Welcome ${info.firstName}`;
                $scope.shouldShowSubMsg = true;
                userAuthenticationService.practiceName = info.practiceName;
                if (info.practiceName) {
                    $scope.practiceName = `${info.practiceName}`;
                    document.title = `Welcome to ${info.practiceName}`;
                }                
                $.notify({ icon: 'fa fa-id-card', message: "Enter email and password below to login." }, { type: "warning" });
                setTimeout(function() { $.notifyClose(); }, 2000);
            }).catch(() => {
                modalService.showMessageModal("Failed to extract client information. Please try again.", "Error", false);
            });
        }
    };

    this.login = function login() {
        $.notify({ icon: 'fa fa-key', message: "Authenticating user...." }, { type: "warning" });
        const loginResource = loginService.login($scope.stateParams.guid, $scope.stateParams.uniqueid, $scope.username, $scope.password);
        loginResource.$promise.then((data) => {
            if (data.errorReport && !!Object.keys(data.erorrReport)) {
                modalService.showMessageModal("Invalid username or password", "Login Failed", true);
                return;
            }
            userAuthenticationService.setLoginParams($scope.stateParams.guid, $scope.stateParams.uniqueid);
            userAuthenticationService.isUserAuthenticated = true;
            userAuthenticationService.sessionToken = data.sessionToken;
            $state.go("main");
            // const clientAnswers = this.getClientAnswers(data.sessionToken, $scope.stateParams.uniqueid);
            // clientAnswers.$promise.finally(() => $state.transitionTo("main", null, {
            //     reload: true,
            //     inherit: false,
            //     notify: true
            // }));
        })
            .catch(() => {
                modalService.showMessageModal("Failed to verify username/password", "Unable To Login", true);

            })
            .finally(() => {
                // setTimeout(() => {
                //     $.notifyClose();
                // }, 1000);
            });

    };

    // this.getClientAnswers = function getClientAnswers(sessionToken, uniqueid) {
    //     const clientInfo = clientService.getClientAnswers(sessionToken, uniqueid);
    //     clientInfo.$promise.then((client) => {
    //         console.log(client);
    //         if (!client.GetClientResult || (client.errorReport && Object.keys(client.errorReport).length)) {
    //             modalService.showMessageModal("Unable to retrieve your details", "Error", true);
    //             return;
    //         }
    //         const info = client.GetClientResult
    //             .find(q => q.data.includes(`"uniqueID":${uniqueid}`));
    //         if (!info) return;
    //         Object.assign(info, JSON.parse(info.data));
    //         $scope.welcomeNote = `Welcome ${info.firstName}`;
    //     });


    //     return clientInfo;
    // };

    this.init();

};

export { loginController };