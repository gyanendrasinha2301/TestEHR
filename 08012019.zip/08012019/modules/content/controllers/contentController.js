import { userAuthenticationService } from "../../common/services/userAuthenticationService";
import { clientService } from "../../client/services/clientService";

"use strict";

const contentController = function contentController($scope, $location, $anchorScroll, modalService, contentService, userAuthenticationService, clientService) {
    $scope.currentTab = null;
    const tabs = ["basicSection", "pregnancySection", "pastPregnanciesSection", "healthSection", "summarySection"];
    this.init = function init() {
        $scope.currentTab = "basicSection";
        $scope.displaySaveButton = !userAuthenticationService.isNewUser;
        $scope.saveButtonNotReqd = ["pastPregnanciesSection", "summarySection"];
        $('[data-toggle="popover"]').popover();

        $scope.error = null;
        $scope.isProcessing = true;
        $.notify({ icon: 'fa fa-cloud-download', message: "Loading questions...." }, {
            type: "warning"
            , showProgressbar: true
        });

        $scope.questionJson = contentService.getQuestionGroups(userAuthenticationService.sessionToken);
        $scope.allQuestionGroups = [];
        $scope.questionJson.$promise.then(() => {
            $scope.isProcessingAnswers = false;
            if (!userAuthenticationService.isNewUser) {
                $scope.isProcessingAnswers = true;
                const clientAnswers = this.getClientAnswers(userAuthenticationService.sessionToken, userAuthenticationService.uniqueid);
                clientAnswers.$promise.then(() => {
                    $scope.allQuestionGroupsWithQuestions = contentService.getAllQuestionGroupsWithQuestions();
                    $scope.allQuestionGroups = contentService.getAllQuestionGroups();
                })
                    .finally(() => $scope.isProcessingAnswers = false);
                return;
            }
            $scope.allQuestionGroupsWithQuestions = contentService.getAllQuestionGroupsWithQuestions();
            $scope.allQuestionGroups = contentService.getAllQuestionGroups();
            //const clientAnswers = this.getClientAnswers(userAuthenticationService.sessionToken, userAuthenticationService.uniqueid);
        })
            .catch((error) => {
                $scope.error = error;
                console.log(error);
                $.notifyClose();
                $.notify({ icon: 'fa fa-bug', message: "Failed to load the questions" }, { type: "danger" });
            })
            .finally(() => {
                $scope.isProcessing = false;
                if (!$scope.error && !userAuthenticationService.isNewUser)
                    $.notify({ icon: 'fa fa-map', message: "Mapping user's existing answers" });
                //$.notifyClose();
            });
    };

    this.getClientAnswers = function getClientAnswers(sessionToken, uniqueid) {
        const clientInfo = clientService.getClientAnswers(sessionToken, uniqueid);
        clientInfo.$promise.then((client) => {
            console.log(client);
            if (!client.GetClientResult || (client.errorReport && Object.keys(client.errorReport).length)) {
                modalService.showMessageModal("Unable to retrieve your details", "Error", true);
                return;
            }
            const info = client.GetClientResult
                .find(q => q.data.includes(`"uniqueID":${uniqueid}`));
            if (!info) return;
            Object.assign(info, JSON.parse(info.data));
            $scope.welcomeNote = `Welcome ${info.firstName}`;
        });


        return clientInfo;
    };

    this.goNext = function goNext() {
        let tabToSetActive = "";
        if (!$scope.currentTab) return;

        const currentTabIndex = tabs.indexOf($scope.currentTab);
        if (currentTabIndex === tabs.length - 1) return;
        setTabHeaderAsActive(tabs[currentTabIndex + 1]);
        this.SetActiveTab(tabs[currentTabIndex + 1]);
        scrollToTop();
    }

    this.goBack = function goBack() {
        let tabToSetActive = "";
        if (!$scope.currentTab) return;

        const currentTabIndex = tabs.indexOf($scope.currentTab);
        if (currentTabIndex === 0) return;
        setTabHeaderAsActive(tabs[currentTabIndex - 1]);
        this.SetActiveTab(tabs[currentTabIndex - 1]);
        scrollToTop();
    }

    this.SetActiveTab = function SetActiveTab(tabName) {

        if ($scope.currentTab) {
            if ($scope.currentTab === tabName) return;
            this.save($scope.contentForm, tabName);
        }
        else
            saveAndContinueCallback();
    };

    this.save = function save(mainForm, tabName) {
        //Object.keys(form).filter(key =>!key.startsWith("$")).filter(key =>form[key].$dirty)
        // contentService.saveSection($scope.currentTab);
        if (!mainForm) {
            saveAndContinueCallback(tabName);
            return;
        }

        const form = mainForm[$scope.currentTab + "Form"];

        if (!tabName) {
            contentService.saveForm(form);
            // modalService.showSaveModal();
            return;
        }


        const saveDetails = () => {
            if (!userAuthenticationService.isNewUser)
                contentService.saveForm(form);
            //modalService.showSaveModal();
            saveAndContinueCallback(tabName, form);
        };

        if (form) {
            if (form.$pristine) {
                saveAndContinueCallback(tabName, form);
                return;
            }
            form.$setSubmitted();
            if (form.$error && form.$error["required"]) {
                const listOfFields = form.$error["required"].map(e => e.$$attr.title);
                modalService.showConfirmationBeforeNavigatingModal(listOfFields, saveDetails, discontinueNavCallback);
            }
            else {
                saveAndContinueCallback(tabName);
            }
        }
    };

    this.submit = function submit(form) {
        if (!userAuthenticationService.isNewUser) clientService.submit();
        else clientService.submitNewUser(form);
    }

    const saveAndContinueCallback = (tabName, form) => {
        if (!tabName) return;
        if (form  && !userAuthenticationService.isNewUser) form.$setPristine();
        $scope.currentTab = tabName;
        $scope.displaySaveButton = userAuthenticationService.isNewUser || $scope.saveButtonNotReqd.includes(tabName)
            ? false : true;
        $(`#${$scope.tabName}Tab`).blur();
    };

    const discontinueNavCallback = () => setTabHeaderAsActive($scope.currentTab);

    function setTabHeaderAsActive(tabName) {
        $(".nav-link").removeClass("active");
        $(`#${tabName}Tab`).addClass("active");
    }

    function scrollToTop() {
        $location.hash('tabContainer');

        // call $anchorScroll()
        $anchorScroll();
    }

    this.init();

}

export { contentController };