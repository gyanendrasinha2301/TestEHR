"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const pregnancyController = function pregnancyController($scope, clientService, utilityService) {

    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $scope.groups = this.extractGroupsForTheSection("pregnancySection");

        this.getQuestionGroupswithQuestions();
        const currentPregnancyGroup = $scope.groups.find(g => g.Name === "currentPregnancy");
        //Hiding all subgroups if user is not pregnant
        const isPregnantQues = currentPregnancyGroup
            .questions.find(q => q.Title === "Are You Pregnant?");
        if (!isPregnantQues.Answer) {
            $scope.groups.filter(g => g.Name !== "currentPregnancy")
                .forEach(g => g.hide = true);
        }
        $scope.$watch(() => isPregnantQues.Answer, (newAnswer) => {
            $scope.groups.filter(g => g.Name !== "currentPregnancy")
                .forEach(g => g.hide = !newAnswer);
        });

        // Adding watch for estimated due date
        // Adding watch on all reqd fileds which are subquestions to is pregnant ques
        const subQuestions = Object.keys(isPregnantQues.subQues).map(key => isPregnantQues.subQues[key])[0];
        if (!subQuestions || subQuestions.length <= 0) return;

        const dueDateBasedOnQuestion = subQuestions
            .find(q => q.Title === "Est. Due Date Based On");

        const estDueDateQuestion = subQuestions
            .find(q => q.Title === "Est. Due Date");

        if (!dueDateBasedOnQuestion || !estDueDateQuestion) return;

        //Getting all questions based on the "Est. Due Date Based On" question's combo value 
        const dueDateRelatedQuestions = this.GetArray(dueDateBasedOnQuestion.comboOptions)
            .reduce((result, val) => {
                const ques = subQuestions.find(q => q.Title.includes(val));
                if (!ques) return result;
                result.push(ques);
                return result;
            }, []);

        dueDateRelatedQuestions.forEach(question => {
            $scope.$watch(() => question.Answer, (newAnswer) => {
                this.calculateEDD(dueDateBasedOnQuestion, dueDateRelatedQuestions, estDueDateQuestion);
            });
        });
        $scope.$watch(() => dueDateBasedOnQuestion.Answer, (newAnswer) => {
            this.calculateEDD(dueDateBasedOnQuestion, dueDateRelatedQuestions, estDueDateQuestion);
        });


    };

    this.calculateEDD = function calculateEDD(dueDateBasedOnQuestion, dueDateRelatedQuestions, estDueDateQuestion) {
        if (!estDueDateQuestion) return;
        if (!dueDateBasedOnQuestion || !dueDateRelatedQuestions) {
            estDueDateQuestion.Answer = null;
            return;
        }

        const newAnswer = dueDateBasedOnQuestion.Answer;
        if (newAnswer === "Please Select") {
            //Remove value
            estDueDateQuestion.Answer = null;
            return;
        }
        const estDueDateBasedOn = dueDateRelatedQuestions
            .find(q => q.Title.includes(newAnswer));

        estDueDateQuestion.Answer = (estDueDateBasedOn && estDueDateBasedOn.Answer) ?
            utilityService.calculateEDD(estDueDateBasedOn) : null;
    }

    this.init();
};

export { pregnancyController };

