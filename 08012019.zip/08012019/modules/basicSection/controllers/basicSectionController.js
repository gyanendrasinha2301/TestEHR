"use strict";

import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const basicSectionController = function basicSectionController($scope, clientService, utilityService, userAuthenticationService) {
    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        $scope.groups = this.extractGroupsForTheSection("basicSection");

        this.getQuestionGroupswithQuestions();

        if(userAuthenticationService.isNewUser){
            clientService.setRecordNumber();
        }
    };

    this.init();
};

export { basicSectionController };