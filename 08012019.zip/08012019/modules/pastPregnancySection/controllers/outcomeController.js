"use strict";
import { commonControllerBase } from "../../common/controllers/commonControllerBase";

const outcomeController = function outcomeController($scope, clientService, utilityService) {
    commonControllerBase.apply(this, arguments);

    this.init = function init() {
        this.createSubQuestion();
        if ($scope.selectedAnswerGroup
            && $scope.selectedAnswerGroup.subGroups
        ) {

            const pregnancyDetails = $scope.selectedAnswerGroup.subGroups.filter(s => s.summary !== "PregnancyDetails" && s.summary != "Complications");

            if (!pregnancyDetails[$scope.subGroupIndex]) return;
            const subAnswerGroup = pregnancyDetails[$scope.subGroupIndex];

            $scope.subQuestion.answer = subAnswerGroup.summary;
            this.onSelectionOfOutcome($scope.subQuestion.answer, subAnswerGroup);

            if (subAnswerGroup.summary === "Live Birth") {
                //Check if there are more 'Live Birth' pregnancy left to render, then dont add complications yet.
                const subArray = pregnancyDetails.splice($scope.subGroupIndex + 1, pregnancyDetails.length - 1);
                if (subArray.some(s => s.summary === "Live Birth")) return;

                const complicationDetails = $scope.selectedAnswerGroup.subGroups.find(s => s.summary === "PregnancyDetails" || s.summary === "Complications");
                if (!complicationDetails) return;
                this.onSelectionOfOutcome("PregnancyDetails", complicationDetails);
            }

        }
    };

    this.createSubQuestion = function createSubQuestion() {
        $scope.subQuestion = {
            title: "Outcome",
            id: "Outcome",
            values: ["Please Select"],
            isRequired: true,
            defaultValue: "Please Select",
            answer: "Please Select"
        };
        $scope.mainGroup.childGroups.forEach(group => {
            const shouldhideRegex = new RegExp(/hideInViewMode\\*":\s*1/, "i");
            if (shouldhideRegex.test(group.data)) return;
            const groupName = this.extractGroupName(group);
            if (!groupName) return;
            $scope.subQuestion.values.push(groupName);
        });
    };

    this.onSelectionOfOutcome = function onSelectionOfOutcome(value, answerGroup) {
        // $scope.subQuestionGroups = $scope.subQuestionGroups || [];
        const priorSubQuestionGroups = angular.copy($scope.subQuestionGroups);
        //$scope.subQuestionGroups = answerGroup ? ($scope.subQuestionGroups || []) : [];
        $scope.subQuestionGroups = (value === "PregnancyDetails") ? ($scope.subQuestionGroups || []) : [];
        if (value === "Please Select") return;
        //$scope.subQuestionGroups = $scope.subQuestionGroups || [];

        if ((value !== "PregnancyDetails"))
            $scope.allOutcomes[$scope.subGroupIndex] = value;

        const selectedAnswers = answerGroup ? answerGroup.answers : null;
        // let complicationAnswer;
        // if (value === "PregnancyDetails" && selectedAnswers && selectedAnswers.length > 0)
        //     complicationAnswer = selectedAnswers[0].answers;

        const group = $scope.mainGroup.childGroups.find(g => g.data.includes(`"groupName":"${value}"`));
        if (!group || !group.questions.length) {
            console.log("no ques for: ", group.Title);
            return;
        }
        const selectedGroup = angular.copy(group);
        const questions = selectedGroup.questions
            .map((q, index) => {
                Object.assign(q, JSON.parse(q.data));
                q.uniqueId = this.extractUniqueId(q);
                let answer = selectedAnswers ? selectedAnswers.find(a => a.data.includes(`"question":${q.uniqueId}`)) : null;

                q.type = utilityService.getQuestionType(q);
                q.Id = this.generateId(q.questionName) + `_${index}`;
                q.Title = this.CapitalizeString(q.text);
                q.Answer = this.getAnswerOrDefault(q, selectedAnswers, true);
                q.subQues = this.createSubGroups(q, q.subQues, "parentQuestionAnswer");
                q.units = this.getUnits(q.text);
                q.answerGroup = answer ? answer.answerGroup : "";
                q.answerId = answer ? answer.answerId : "";
                return q;
            })
           // .filter(q => !q.hideInEditMode)
            .sort((a, b) => this.compare(a, b));

        const obj = {
            'data': selectedGroup.data,
            'questions': questions,
            'uniqueId': this.extractUniqueId(selectedGroup)
        };

        this.createPrintQuestionsSubGroup(obj);
        obj.questions = obj.questions.filter(q => !q.hideInEditMode);
        // const complicationsIndex = $scope.subQuestionGroups.findIndex(g => g.data.includes(`"groupName":"PregnancyDetails"`));
        // if (!isNaN(index) && index >= 0 && $scope.subQuestionGroups.length - 1 >= index) {
        //     if (complicationsIndex > -1 && complicationsIndex <= index) index++;
        //     $scope.subQuestionGroups.splice(index, 1, angular.copy(obj));
        // }
        // else
        //     $scope.subQuestionGroups.push(angular.copy(obj));

        // if (!$scope.subQuestionGroups.some(g => g.data.includes("Live Birth"))) {
        //     const complicationIndex = $scope.subQuestionGroups.findIndex(g => g.data.includes(`"groupName":"PregnancyDetails"`));
        //     if (complicationIndex < 0) return;
        //     $scope.subQuestionGroups.splice(complicationIndex, 1);
        //     return;
        // }
        $scope.subQuestionGroups.push(angular.copy(obj));
        if (answerGroup) return;

        const liveBirthCount = Object.keys($scope.allOutcomes).filter(key => $scope.allOutcomes[key] === "Live Birth");
        // if (liveBirthCount.length <= 0) {
        //     //remove complications
        //     const complicationIndex = $scope.subQuestionGroups.findIndex(g => g.data.includes(`"groupName":"PregnancyDetails"`));
        //     if (complicationIndex < 0) return;
        //     $scope.subQuestionGroups.splice(complicationIndex, 1);
        // }
        if ($scope.selectedAnswerGroup && $scope.selectedAnswerGroup.subGroups.find(s => s.summary === "PregnancyDetails" || s.summary === "Complications")) return;
        if ((liveBirthCount.length == 1) && value === "Live Birth") {
            this.onSelectionOfOutcome("PregnancyDetails");
        }
        if (liveBirthCount.length > 1) {
            if (!priorSubQuestionGroups) return;
            const complicationsGroup = priorSubQuestionGroups.find(g => g.data.includes(`"groupName":"PregnancyDetails"`));
            if (complicationsGroup) $scope.subQuestionGroups.push(complicationsGroup);
        }
        //this.onSelectionOfOutcome("PregnancyDetails");
        // if ($scope.subQuestionGroups.some(g => g.data.includes(`"groupName":"PregnancyDetails"`))) return;
        // if ($scope.selectedAnswerGroup && $scope.selectedAnswerGroup.subGroups.find(s => s.summary === "Complications")) return;
        // if (value === "Live Birth") this.onSelectionOfOutcome("PregnancyDetails");
    };


    this.cancel = function cancel() {
        $scope.onCancel();
    }
    this.save = function save() {
        $scope.onSave({ $item: $scope.currentAnswer });
    }
    this.init();
};

export { outcomeController };