"use strict";

const saveService = function saveService($resource, userAuthenticationService) {

    this.actionType = { 'update': 0, 'insert': 1, 'delete': 2, 'refresh': 3 };

    this.init = function init() {
        this.saveResource = $resource("https://www3.mobilemidwifeehr.com/MidwifeService.svc/jsons/:actionName", {},
            { 'save': { 'method': "POST", 'params': { 'actionName': "ReceiveTransactions4" } } }
        );
    };

    this.submitNewUser = function submitNewUser() {
        const transaction = [];
        //create client transaction
        transactions.push(clientService.getClientObject());
        //create user transaction

    }

    this.saveTransactions = function saveTransactions(transactions) {
        transactions = transactions || [];
        const saveObj = {
            'sessionToken': userAuthenticationService.sessionToken,
            'isLastBatch': 1,
            'isWebPortalOrLogUploadOrAndroid': true,
            'transactions': transactions
        };
        console.log(saveObj);
        return this.saveResource.save(saveObj);
    };


    this.createAnswerTransactionObject = function createAnswerTransactionObject(group, question, answerGroupId, uniqueId, userId, actionTypeValue, property) {
        const transaction = createTrasaction(uniqueId, actionTypeValue, "1", `${group.Name}-${getQuestionText(question)}`, userId);
        transaction.data = buildData(group, question, answerGroupId, uniqueId, property);
        return transaction;
    }

    this.createAnswerGroupTransactionObj = function createAnswerGroupTransactionObj(uniqueId, groupName, questionGroupId, parentAnswerGroupId, userId, actionTypeValue) {
        const transaction = createTrasaction(uniqueId, actionTypeValue, "2", `${groupName}-`, userId);
        transaction.data = buildAnswerGroupData(questionGroupId, parentAnswerGroupId, uniqueId);
        return transaction;
    };

    this.createClientObj = function createClientObj(uniqueId, userId) {
        const transaction = createTrasaction(uniqueId, this.actionType.insert, "3", "", userId);
        //Add data property 
        transaction.data = buildClientData(uniqueId, userId);
        return transaction;
    };

    this.createUserObj = function createUserObj(questionGroupId, clientId, uniqueId) {
        const transaction = createTrasaction(uniqueId, this.actionType.insert, "2", "Users -");
        transaction.data = buildUsersData(questionGroupId, clientId, uniqueId);
        return transaction;
    };

    function createTrasaction(uniqueId, actionTypeValue, objectName, detailText, userId) {
        return {
            'uniqueIDStr': uniqueId,
            'actionType': actionTypeValue,
            'objectName': objectName,
            'createdDate': `/Date(${getCurrentDate()})/`,
            'details': detailText,
            'byIDStr': userId || uniqueId
        }
    };
    function buildData(group, question, answerGroupId, uniqueid, property) {
        return `{"createdDate":"\/Date(${getCurrentDate()})\/","lastUpdated":"\/Date(${getCurrentDate()})\/",` +
            ` "answerGroup":${answerGroupId},"question":${question.uniqueId},"uniqueIDStr":${uniqueid},` +
            ` ${getAnswerKey(question, property)}}`;
    };

    function buildAnswerGroupData(questionGroupId, parentAnswerGroupId, uniqueid) {
        return `{"IsNew":0,"active":1,"createdDate":"\/Date(${getCurrentDate()})\/",` +
            ` "parentAnswerGroup":${parentAnswerGroupId},"questionGroup":${questionGroupId},"uniqueIDStr":${uniqueid}` +
            ` }`;
    };

    function buildUsersData(questionGroupId, clientId, uniqueId) {
        return `{"IsNew":0,"active":1,"createdDate":"\/Date(${getCurrentDate()})\/","client":${clientId},"clientObj":${clientId},"questionGroup":${questionGroupId},"uniqueIDStr":${uniqueId}}`;
    };

    function buildClientData(clientId, userId) {
        return `{"active":1,"createdDate":"\/Date(${getCurrentDate()})\/","lastUpdated":"\/Date(${getCurrentDate()})\/","user":${userId},"uniqueIDStr":${clientId}}`;
    };
    function getQuestionText(q) {
        return q.questionName || q.text || q.textInViewMode || q.waterMark || "";
    };

    function getCurrentDate() {
        const timezone = new Date().toString().match(/([-\+][0-9]+)\s/)[1];
        return `${Date.now()}${timezone}`;
    };

    function getDateWithTimeZone(value) {
        const timezone = new Date().toString().match(/([-\+][0-9]+)\s/)[1];
        return `${Date.parse(value)}${timezone}`;
       
    };
    
    function getAnswerKey(question, property) {
        const answer = property? question[property] || question.Answer : question.Answer;
        if(!!property && property.toLowerCase() !== "answer"){
            if(question.type === "yesNoWithComment") return `"comment":"${answer}"`;
        }
        if (question.hasTextBox) return `"comment":"${answer}"`;
        if (question.numberStepper) return `"number":${answer}`;
        if (question.hasCombo) return `"comboSelection":"${answer}"`;
        if (question.hasYesNo) return `"yesNo":${answer ? 1 : 0}`;
        if (question.hasDateTime) return `"dateTime":"\/Date(${getDateWithTimeZone(answer) })\/"`;
    };

    this.init();

};

export { saveService };