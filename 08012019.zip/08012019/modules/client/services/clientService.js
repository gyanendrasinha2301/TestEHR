"use strict";

const clientService = function clientService($resource, userAuthenticationService, utilityService, saveService) {

    this.clientAnswers = null;
    this.answerGroupsWithAnswers = [];
    this.allQuestions = [];
    this.allQuestionGroups = [];
    this.questionGroups = [];
    this.clientObject = null;
    this.isClientObjectUpdated = false;
    this.clientId = null;
    this.userId = null;
    this.pastPregnancyTransactions = [];
    this.summaryTabPastPregnancyDetails = [];
    this.allGroupQuestions = [];
    this.questionsToBeResetAfterSave = [];
    
    this.reqQuestionGroups =
        [{
            Id: "BasicInfo",
            Title: "Basic Information",
            Name: "Basic Information",
            Section: "basicSection",
            IsOpen: true
        },
        {
            Id: "FinancialInfo",
            Title: "Financial Information",
            Name: "Financial Information",
            Section: "basicSection",
            IsOpen: true
        },
        {
            Id: "CurrentPregnancy",
            Title: "Current Pregnancy",
            Name: "currentPregnancy",
            Section: "pregnancySection",
            IsOpen: true
        },
        {
            Id: "MotherHistory",
            Title: "Your Mother's History",
            Name: "Your Mother's History",
            Section: "pregnancySection",
            IsOpen: true
        },
        {
            Id: "FatherOfBaby",
            Title: "Father of Baby",
            Name: "Father of Baby",
            Section: "pregnancySection",
            IsOpen: true
        },
        {
            Id: "FatherHistory",
            Title: "Father's History",
            Name: "Father's History",
            Section: "pregnancySection",
            IsOpen: true
        },
        {
            Id: "GeneticHistory",
            Title: "Genetic History",
            Name: "Genetic History",
            Section: "pregnancySection",
            IsOpen: true,
            defaultWidth: 6
        },
        {
            Id: "Past Pregnancy",
            Title: "Past Pregnancy",
            Name: "Pregnancy",
            Section: "pastPregnanciesSection",
            IsOpen: true
        }, {
            Id: "FamilyHistory",
            Title: "Your Family History",
            Name: "Family History",
            Section: "healthSection",
            IsOpen: true
        },
        {
            Id: "health",
            Title: "Your Health",
            Name: "Your History",
            Section: "healthSection",
            IsOpen: true
        },
        {
            Id: "Medications",
            Title: "Medications",
            Name: "MedicationStatus",
            Section: "healthSection",
            IsOpen: true
        },
        {
            Id: "GynecologicHistory",
            Title: "Gynecologic History",
            Name: "gynHistory",
            Section: "healthSection",
            IsOpen: true
        }
        ];

    this.init = function init() {
        this.clientResource = $resource("https://www3.mobilemidwifeehr.com/MidwifeService.svc/jsons/GetClient/:guid/:uniqueid",
            {},
            { 'getAnswers': { 'method': 'GET', params: { 'guid': 0, 'uniqueid': 0 } } }
        );
    };

    this.setAllGroupQuestions = function setAllGroupQuestions(questions) {
        this.allGroupQuestions.push(...questions);
    };

    this.setQuestionGroups = function setQuestionGroups(questionGroups) {
        this.allQuestionGroups = questionGroups;
    };

    this.setQuestions = function setQuestions(questions) {
        this.allQuestions = questions;
    };

    this.storeUpdatedGroups = function storeUpdatedGroups(groups) {
        this.questionGroups = [...this.questionGroups, ...groups];
    };

    this.getClientId = function getClientId() {
        if (this.clientId) return this.clientId;
        const clientObj = this.getClientObject();
        return this.clientId = utilityService.extractUniqueId(clientObj);
    };


    this.getUserId = function getUserId() {
        if (this.userId) return this.userId;
        const userObj = this.getUserObject();
        return this.userId = utilityService.extractUniqueId(userObj);
    };

    this.getClientObject = function getClientObject() {
        if (this.clientObject) return this.clientObject;
        if (userAuthenticationService.isNewUser) return this.clientObject = this.createClientObject();
        this.clientObject = this.clientAnswers.GetClientResult.find(q => q.objectName === "3");
        if(!this.clientObject){
            $.notify({ icon: 'fa fa-stop-circle', message: "Failed to retrieve client object." }, { type: "danger" });
            return;
        }
        if (this.clientObject.hasOwnProperty("byID")) delete this.clientObject.byID;
        if (!this.userId) this.userId = this.getUserId();
        this.clientObject.byIDStr = this.userId;
        
        this.clientId = utilityService.extractUniqueId(clientObj);
        if(this.clientObject.hasOwnProperty("uniqueID")){
            delete this.clientObject.uniqueID;
            this.clientObject.uniqueIDStr = this.clientId;
            if(this.clientObject.data && typeof this.clientObject.data === "string"){
                const uniqueIdReg = new RegExp(/uniqueID/, "i");
                this.clientObject.data.replace(uniqueIdReg, "uniqueIDStr");
            }
        }


        return this.clientObject;
    };

    this.setRecordNumber = function setRecordNumber() {
        let questionGroup = this.allQuestionGroups.find(g => g.data.includes(`"groupName":"Basic Information"`))
        const question = questionGroup.questions.find(q => q.data.includes(`"questionName":"record number"`));
        if (!question) return;
        if (!question.Answer) question.Answer = randomFixedInteger(7);
    }

    this.getUserObject = function getUserObject() {
        if (this.userObject) return this.userObject;
        if (userAuthenticationService.isNewUser) return this.userObject = this.createUserObject();
        const clientId = utilityService.extractUniqueId(this.clientObject);
        return this.userObject = this.clientAnswers.GetClientResult.find(q => q.data.includes(`"client":${clientId}`));
    };

    this.createClientObject = function createClientObject() {
        this.clientId = this.clientId || this.getUniqueIdentifier();
        this.userId = this.getUserId();
        return saveService.createClientObj(this.clientId, this.userId);
    }

    this.createUserObject = function createUserObject() {
        this.clientId = this.clientId || this.getUniqueIdentifier();
        this.userId = this.userId || this.getUniqueIdentifier();
        const questionGroup = this.allQuestionGroups.find(g => g.data.includes(`"groupName":"Users"`));
        if (!questionGroup) {
            $.notify({ icon: 'fa fa-stop-circle', message: "Failed to retrieve question group for User" }, { type: "danger" });
            console.error("Failed to retrieve question group for User");
            return;
        }
        const questionGroupId = utilityService.extractUniqueId(questionGroup);
        return saveService.createUserObj(questionGroupId, this.clientId, this.userId);
    }

    this.updateClientObject = function updateClientObject(ques) {
        if (!this.clientObject) this.clientObject = this.createClientObject();
        this.isClientObjectUpdated = true;
        const clientObj = this.clientObject;
        const data = JSON.parse(clientObj.data);
        let keyToUpdate = ques.saveToLocation;
        if (!keyToUpdate) return;
        if (keyToUpdate.includes(".")) keyToUpdate = keyToUpdate.split(".")[1];
        data[keyToUpdate] = ques.Answer;
        data["lastUpdated"] = `"\/Date(${getCurrentDate()})\/"`;
        data["actionType"] = userAuthenticationService.isNewUser ?
            this.actionType.insert : this.actionType.update;
        clientObj.data = JSON.stringify(data);
    }

    this.saveClientObject = function saveClientObject() {
        const clientObj = this.clientObject;
        if (!this.isClientObjectUpdated) {
            const data = JSON.parse(clientObj.data);
            data["actionType"] = this.actionType.refresh;
            clientObj.data = JSON.stringify(data);
        }
        saveService.saveTransactions([clientObj]);
    }

    this.submit = function submit() {
        saveService.saveTransactions();
    };

    this.getClientAnswers = function getClientAnswers(guid, uniqueid) {
        if (userAuthenticationService.isNewUser) {
            this.createClientObject();
            this.createUserObject();
            return;
        }
        const resource = this.clientResource.getAnswers({ guid, uniqueid });
        resource.$promise.then(data => {
            this.clientAnswers = data;
            this.constructAnwserGroups(data);
            this.getClientObject();
        });
        return resource;
    };

    this.getClientInfo = function getClientInfo(uniqueid) {
        if (!this.clientAnswers) return;
        const client = this.clientAnswers;
        if (!client.GetClientResult || (client.errorReport && Object.keys(client.errorReport).length)) {
            return;
        }
        const info = client.GetClientResult
            .find(q => q.objectName === "3");
        if (!info) return;
        Object.assign(info, JSON.parse(info.data));
        return info;
    };

    this.getAnswerFor = function getAnswerFor(questionId) {
        if (!this.clientAnswers) return;
        const answerContainer = this.clientAnswers.GetClientResult;
        return answerContainer
            .find(a => a.data.includes(`"question":${questionId}`));
    };

    this.getAnswerById = function getAnswerById(id) {
        if (!this.clientAnswers) return;
        const answerContainer = this.clientAnswers.GetClientResult;
        return answerContainer
            .find(a => a.data.includes(`"uniqueID":${id}`));
    };

    this.getAnswerGroupsFor = function getAnswerGroupsFor(questionGroupId) {
        if (!this.answerGroupsWithAnswers) return [];
        return questionGroupId ?
            this.answerGroupsWithAnswers
                .filter(a => a.data.includes(`"questionGroup":${questionGroupId}`))
            : this.answerGroupsWithAnswers;
    };

    this.constructAnwserGroups = function constructAnwserGroups() {
        if (!this.clientAnswers || !this.clientAnswers.GetClientResult) return;
        const allAnswerGroups = this.clientAnswers.GetClientResult.filter(a => a.objectName === "2");
        const allAnswers = this.clientAnswers.GetClientResult.filter(a => a.objectName === "1");

        allAnswerGroups.forEach(group => {
            let id = utilityService.extractUniqueId(group);
            group.answers = allAnswers.filter(q => q.data.includes(id));
        });

        allAnswerGroups.forEach(group => {
            if (group.data.includes("clientObj")) return;
            let id = utilityService.extractUniqueId(group);
            group.subGroups = allAnswerGroups.reduce((subgroup, g) => {
                if (g.data.includes(`"parentAnswerGroup":${id}`)) {
                    subgroup.push(g);
                    g.isSubGroup = true;
                }
                return subgroup;
            }, []);

        });
        this.answerGroupsWithAnswers = allAnswerGroups;
    };

    this.mapAnswersToQuestions = function mapAnswersToQuestions() {
        const groupsToDisplay = [];
        $scope.allAnswerGroups.forEach(answerGroup => {
            let questionGroupId = utilityService.extractQuestionGroupId(answerGroup);
            const questionGroup = this.allQuestionGroups.find(group => group.data.includes(`"uniqueID":${questionGroupId}`));
            if (!questionGroup || !questionGroup.questions) return;
            answerGroup.Answers.forEach(answer => {
                let questionId = utilityService.extractQuestionId(answer);
                let question = this.allQuestions.questions.find(q => q.data.includes(`"uniqueID":${questionId}`));
                if (!question) return;
                question.savedAnswer = readAnswer(answer, question);
            });
            if (questionGroup.questions.some(q => !!q.savedAnswer)) {
                groupsToDisplay.push(questionGroup);
            }
        });
    };

    this.mapAnswerGroupToQuestionGroup = function mapAnswerGroupToQuestionGroup(answerGroup, questionGroup) {
        answerGroup.answers.forEach(answer => {
            let questionId = utilityService.extractQuestionId(answer);
            let question = questionGroup.questions.find(q => q.data.includes(`"uniqueID":${questionId}`));
            if (!question) return;
            question.Answer = this.extractAnswer(question, answer);
        });

    };


    this.saveForm = function saveForm(form, sectionName) {
        if (!form) return;

        const elementsToBeSaved = form.$$controls
            .filter(key => key.$dirty);

        let transactionData = [];
        transactionData = transactionData.concat(this.saveMultiButtonTypeObjects(form));
        if ((!elementsToBeSaved || elementsToBeSaved.length <= 0) && transactionData.length <= 0) {

            $.notify({ icon: 'fa fa-stop-circle', message: "There are no changes to be saved" }, { type: "danger" });
            return;
        }
        $.notify({ icon: 'fa fa-floppy-o', message: "Save in progress..." }, {
            showProgressbar: true
        });

        this.getUserId();
        this.getClientId();

        const elements = [];
        elementsToBeSaved.forEach(elt => {
            //let elt = form[element];
            const eltAttributes = elt.$$attr;
            const eltQuestionId = eltAttributes.questionId;

            if (!eltQuestionId || elements.includes({ eltQuestionId: eltAttributes.ngModel })) return;
            elements.push({ eltQuestionId: eltAttributes.ngModel });
            let property = eltAttributes.ngModel.split(".").slice(-1).pop();
            property = property || "Answer";

            let question = this.allGroupQuestions.find(q => q.data.includes(`"uniqueID":${eltQuestionId}`));
            if (question[property] === utilityService.GetDefaultValue(question)) return;
            //get group for the question
            const groupId = utilityService.extractQuestionGroupId(question);
            const group = this.questionGroups.find(q => q.data.includes(`"uniqueID":${groupId}`))
            const answersGroup = this.getAnswerGroupsFor(groupId);
            const answersFromTheGroup = this.createAnswerTransaction(question, group, answersGroup[0], property);
            if (answersFromTheGroup)
                transactionData = [...transactionData, ...answersFromTheGroup];
        });

        if (!transactionData || transactionData.length <= 0) return;
        const saveTransactionResource = saveService.saveTransactions(transactionData);
        // this.saveClientObject();
        saveTransactionResource.$promise.then(() => {
            this.saveClientObject();
            setTimeout(() => {
                form.$setPristine();
                this.resetQuestionsAfterSave();
                $.notifyClose();
                $.notify({ icon: 'fa fa-check', message: "Changes successfully saved" }, { type: "success" });
            }, 3000);
        }).catch(() => {
            //temp
            //form.$setPristine();
            $.notifyClose();
            $.notify({ icon: 'fa fa-chain-broken', message: "Failed to save data. Please try again." }, { type: "danger" });
        });
    };

    this.getTransactionForElement = function getTransactionForElement(elt) {
        const eltAttributes = elt.$$attr;
        const eltQuestionId = eltAttributes.questionId;
        if (!eltQuestionId) return;
        let question = this.allQuestions.find(q => q.data.includes(`"uniqueID":${eltQuestionId}`));
        if (question.Answer === utilityService.GetDefaultValue(question)) return;
        //get group for the question
        const groupId = utilityService.extractQuestionGroupId(question);
        const group = this.questionGroups.find(q => q.data.includes(`"uniqueID":${groupId}`))
        const answersGroup = this.getAnswerGroupsFor(groupId);
        return this.createAnswerTransaction(question, group, answersGroup[0]);
    };

    this.createAnswerTransaction = function createAnswerTransaction(question, group, answerGroup, property) {
        if (!group) return null;
        const answerGroupId = utilityService.extractUniqueId(answerGroup);
        const transactionData = [];

        const exisitingAnswer = this.getAnswerFor(question.uniqueId);
        if (exisitingAnswer && !this.doesQuestionHasDifferentAnswer(question, exisitingAnswer)) return;
        let uniqueId = this.getUniqueIdentifier(exisitingAnswer);
        const actionTypeValue = !!exisitingAnswer ? this.actionType.update : this.actionType.insert;

        const transactionObject = saveService.createAnswerTransactionObject(group, question, answerGroupId, uniqueId, this.userId, actionTypeValue, property);
        transactionData.push(transactionObject);

        return transactionData;

    };

    this.submitNewUser = function submitNewUser(mainForm) {
        let transactions = [];
        $.notify({ icon: 'fa fa-floppy-o', message: "Save in progress..." }, {
            showProgressbar: true
        });
        //get new client transaction
        transactions.push(this.getClientObject());
        //get new user transaction
        transactions.push(this.getUserObject());
        //const forms = [...$scope.reqQuestionGroups.map(group => mainForm[group.section + "Form"])];
        const formList = this.reqQuestionGroups.reduce((result, group) => {
            if (result.some(r => r.section === group.Section)) return result;
            result.push({ 'section': group.Section, 'form': mainForm[group.Section + "Form"] });
            return result;
        }, []);

        formList.forEach(formDetail => {
            const formTransactions = this.getTransactionsForForm(formDetail);
            if (formTransactions && formTransactions.length > 0)
                transactions.push(...formTransactions);
            const multiButtonTransactions = this.saveMultiButtonTypeObjects(formDetail.form);
            if (multiButtonTransactions && multiButtonTransactions.length > 0)
                transactions.push(...multiButtonTransactions);
        });

        const groupName = "Basic Information";
        const group = this.allQuestionGroups.find(g => g.data.includes(`"groupName":"${groupName}"`));
        const groupId = utilityService.extractUniqueId(group);
        let answerGroup = transactions.find(a => a.data &&
            a.data.includes(`"questionGroup":${groupId}`));

        if (!answerGroup) {
            const uniqueId = this.getUniqueIdentifier();
            answerGroup = saveService.createAnswerGroupTransactionObj(uniqueId, groupName, groupId, this.userId, this.userId, this.actionType.insert);
            transactions.push(answerGroup);
        }
        const answerGroupId = utilityService.extractUniqueId(answerGroup);
        //get record transaction
        transactions.push(this.getRecordTransaction(group, groupId, groupName, answerGroupId));
        //get password transaction
        transactions.push(this.getPasswordTransaction(group, groupId, groupName, answerGroupId));
        //get past pregnanacy transactions
        if (this.pastPregnancyTransactions) {
            let pastPregTransactions =
                this.pastPregnancyTransactions.reduce((result, t) => {
                    result = [...result, ...t.transactions];
                    return result;
                }, []);
            transactions = transactions.concat(pastPregTransactions);
        }

        const saveTransactionResource = saveService.saveTransactions(transactions);
        saveTransactionResource.$promise.then(() => {
            setTimeout(() => {
                formlist.forEach(f => f.form.$setPristine());
                //form.$setPristine();
                this.resetQuestionsAfterSave();
                $.notifyClose();
                $.notify({ icon: 'fa fa-check', message: "Changes successfully submitted." }, { type: "success" });
            }, 3000);
        }).catch(() => {
            $.notifyClose();
            $.notify({ icon: 'fa fa-chain-broken', message: "Failed to submit data. Please try again." }, { type: "danger" });
        });
    };

    this.getTransactionsForForm = function getTransactionsForForm(formDetail) {
        let transactionData = [];
        //createAnswerGroups for each questionGroup
        const groups = this.reqQuestionGroups.filter(g => g.Section === formDetail.section);
        groups.forEach(reqGroup => {
            const group = this.allQuestionGroups.find(g => g.data.includes(`"groupName":"${reqGroup.Name}"`));
            const groupId = utilityService.extractUniqueId(group);
            const uniqueId = this.getUniqueIdentifier();
            const answerGroup = saveService.createAnswerGroupTransactionObj(uniqueId, reqGroup.Name, groupId, this.userId, this.userId, this.actionType.insert);
            transactionData.push(answerGroup);
        });
        const elementsToBeSaved = formDetail.form
            .$$controls
            .filter(key => key.$dirty);

        if (!elementsToBeSaved || elementsToBeSaved.length <= 0) return transactionData;
        const elements = [];
        elementsToBeSaved.forEach(elt => {
            // let elt = form[element];
            const eltAttributes = elt.$$attr;
            const eltQuestionId = eltAttributes.questionId;
            if (!eltQuestionId || elements.includes({ eltQuestionId: eltAttributes.ngModel })) return;
            elements.push({ eltQuestionId: eltAttributes.ngModel });
            let property = eltAttributes.ngModel.split(".").slice(-1).pop();
            property = property || "Answer";
            let question = this.allGroupQuestions.find(q => q.data.includes(`"uniqueID":${eltQuestionId}`));
            if (question[property] === utilityService.GetDefaultValue(question)) return;
            //get group for the question
            const groupId = utilityService.extractQuestionGroupId(question);
            const group = this.questionGroups.find(q => q.data.includes(`"uniqueID":${groupId}`));
            const answerGroup = transactionData.find(a => a.data.includes(`"questionGroup":${groupId}`));
            const answerGroupId = utilityService.extractUniqueId(answerGroup);
            const answerId = this.getUniqueIdentifier();
            const transaction = saveService.createAnswerTransactionObject(group, question, answerGroupId, answerId, this.userId, this.actionType.insert, property);
            transactionData.push(transaction);
        });

        return transactionData;
    }

    this.getPasswordTransaction = function getPasswordTransaction(group, groupId, groupName, answerGroupId) {
        //"questionName":"password"
        const question = this.allGroupQuestions.find(q => q.data.includes(groupId) && q.data.includes(`"questionName":"password"`));
        question.Answer = utilityService.generatePassword();
        const uniqueId = this.getUniqueIdentifier();
        group.Name = groupName;
        //return saveService.createAnswerTransaction(question, group, answerGroupId, uniqueId, this.userId, this.actionType.insert);
        return saveService.createAnswerTransactionObject(group, question, answerGroupId, uniqueId, this.userId, this.actionType.insert);
    }

    this.getRecordTransaction = function getRecordTransaction(group, groupId, groupName, answerGroupId) {
        //extract answerGroupId
        //"questionName":"record number"
        const question = this.allGroupQuestions.find(q => q.data.includes(groupId) && q.data.includes(`"questionName":"record number"`));
        if (!question.Answer) question.Answer = randomFixedInteger(7);
        const uniqueId = this.getUniqueIdentifier();
        //return saveService.createAnswerTransaction(question, group, answerGroupId, uniqueId, this.userId, this.actionType.insert);
        group.Name = groupName;
        return saveService.createAnswerTransactionObject(group, question, answerGroupId, uniqueId, this.userId, this.actionType.insert);
    }


    this.saveMultiButtonTypeObjects = function saveMultiButtonTypeObjects(form) {
        const transactions = [];
        const mbtControls = form.$$controls.filter(c => c.$$attr && c.$$attr.id && c.$$attr.id.includes("_mbt"));
        mbtControls.forEach(control => {
            const questionId = control.$$attr.questionId;
            //get question by id
            const question = this.getQuestionById(questionId);
            if (!question || !question.isAnswerEdited) return;
            const groupId = utilityService.extractQuestionGroupId(question);
            const group = this.questionGroups.find(q => q.data.includes(`"uniqueID":${groupId}`));
            const groupName = utilityService.extractGroupName(group);
            //getAnswerGroups for question
            const answerGroups = this.getAnswerGroupsFor(groupId);

            if (!question.Answer) {
                //check for existing answersgroups and delete them
                if (answerGroups && answerGroups.length > 0) {
                    answerGroups.foreach(ansGroup => {
                        const ansGroupId = utilityService.extractUniqueId(ansGroup);
                        transactions.push(saveService.createAnswerGroupTransactionObj(ansGroupId, groupName, groupId, this.userId, this.userId, this.actionType.delete));
                    });
                }
                return transactions;
            }

            const options = Object.keys(question.Answer);
            options.forEach(option => {
                const subGroups = (answerGroups && answerGroups.length > 0 && answerGroups[0].subGroups) ?
                    answerGroups[0].subGroups : [];

                const optionAnswerGroups = subGroups.filter(a => a.data.includes(`${option}`));
                //ONLY IF SOMETHING IS EDITED OR ADDED
                if (optionAnswerGroups && optionAnswerGroups.length > 0) {
                    optionAnswerGroups.forEach(ansGroup => {
                        const ansGroupId = utilityService.extractUniqueId(ansGroup);
                        transactions.push(saveService.createAnswerGroupTransactionObj(ansGroupId, groupName, groupId, this.userId, this.userId, this.actionType.delete));
                    });
                }

                //for each option, delete existing answer and create new
                const currentAnswerGroupsForOption = question.Answer[option];
                currentAnswerGroupsForOption.forEach((currentAnswerGroup, index) => {

                    const answerGroupId = this.getUniqueIdentifier();

                    transactions.push(saveService.createAnswerGroupTransactionObj(answerGroupId, groupName, groupId, this.userId, this.userId, this.actionType.insert));
                    //FOR EACH ANSWER CREATE TRANSACTION OBJECT 
                    currentAnswerGroup.questions.forEach(question => {
                        const uniqueId = this.getUniqueIdentifier();

                        transactions.push(saveService.createAnswerTransactionObject(group, question, answerGroupId, uniqueId, this.userId, this.actionType.insert));
                    });
                });
            });
            this.questionsToBeResetAfterSave.push(question);
        });
        return transactions;
    };

    this.resetQuestionsAfterSave = function resetQuestionsAfterSave() {
        if (!this.questionsToBeResetAfterSave || this.questionsToBeResetAfterSave.length <= 0) {
            this.questionsToBeResetAfterSave = [];
            return;
        }

        this.questionsToBeResetAfterSave.foreach(ques => { if (ques.isAnswerEdited) ques.isAnswerEdited = false });
        this.questionsToBeResetAfterSave = [];

    };

    this.doesQuestionHasDifferentAnswer = function doesQuestionHasDifferentAnswer(question, answer) {
        const ans = this.extractAnswer(question, answer);
        return ans !== question.Answer;
    };

    this.extractAnswer = function extractAnswer(question, answer) {
        if (!answer) return null;

        const answerData = JSON.parse(answer.data);

        if (question.hasTextBox) return answerData.comment || answerData.number;
        if (question.numberStepper) return answerData.number;
        if (question.hasCombo || question.multiButtonType) return answerData.comboSelection;
        if (question.hasYesNo) {
            if (answerData.comment) question.comment = answerData.comment;
            return answerData.yesNo ? true : false;
        }
        if (question.hasDateTime) {
            const dateTime = answerData.dateTime;
            const dateReg = new RegExp(/(\d+)\+?(\d+)/, "i");
            const dateGroup = dateReg.exec(dateTime);
            if (!dateGroup) return null;
            const date = parseInt(dateGroup[0]);
            const timezone = parseInt(dateGroup[2]);
            return moment(new Date(date)).format("MM/DD/YYYY");

        }
        return null;
    };

    this.getUniqueIdentifier = function getUniqueIdentifier(answer) {
        if (answer) return utilityService.extractUniqueId(answer);
        return `${randomFixedInteger(16)}`;
    };

    const randomFixedInteger = (length) =>
        Math.floor(Math.pow(10, length - 1) + Math.random() * (Math.pow(10, length) - Math.pow(10, length - 1) - 1));

    function getCurrentDate() {
        const timezone = new Date().toString().match(/([-\+][0-9]+)\s/)[1];
        return `${Date.now()}${timezone}`;
    };

    function getAnswerKey(question) {
        if (question.hasTextBox) return `"comment":"${question.Answer}"`;
        if (question.numberStepper) return `"number":${question.Answer}`;
        if (question.hasCombo) return `"comboSelection":"${question.Answer}"`;
        if (question.hasYesNo) return `"yesNo":${question.Answer ? 1 : 0}`;
        if (question.hasDateTime) `"dateTime":"\/Date(${Date.parse(question.Answer)})\/"`;
    };

    this.getQuestionGroupByName = function getQuestionGroupByName(groupName) {
        return this.allQuestionGroups.find(group => group.data.includes(`"groupName":"${groupName}"`));
    };

    this.getQuestionGroupById = function getQuestionGroupById(groupId) {
        return this.allQuestionGroups.find(group => group.data.includes(`"uniqueID":${groupId}`));
    };

    this.getQuestionByChildGroupName = function getQuestionByChildGroupName(groupName) {
        return this.allQuestions.find(group => group.data.includes(`"childAnswerGroup":"${groupName}"`));
    };

    this.getQuestionById = function getQuestionById(questionId) {
        return this.allGroupQuestions.find(ques => ques.data.includes(`"uniqueID":${questionId}`));
    };

    this.actionType = { 'update': 0, 'insert': 1, 'delete': 2, 'refresh': 3 };

    this.init();
}

export { clientService };